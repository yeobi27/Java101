package server;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import dao.HorseDao;
import dao.Horse_ConditionDao;
import dto.Horse;
import dto.Horse_Condition;

public class HorseUpdate extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField tfKg;
	private JTextField tfAge;
	private JTextField tfCm;
	private JLabel lblName;
	private Horse h;
	private Horse horse;
	private HorseManager hr;
	private JTextField tfSunny;
	private JTextField tfCloud;
	private JTextField tfRain;
	private JButton btnInsert;
	private JButton btnReset;
	private JButton btnClose;
	private JLabel lblImage;
	private Horse_Condition hc;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//HorseUpdate frame = new HorseUpdate();
					// frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */
	public HorseUpdate(Horse horse, Horse_Condition hc, HorseManager hr) throws Exception {
		this.hr = hr;
		this.horse=horse;
		this.hc = hc;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 600, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		JLabel label = new JLabel("[�� ���� ����]");
		label.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 35));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(label, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panImg = new JPanel();
		panel.add(panImg, BorderLayout.NORTH);
		panImg.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setPreferredSize(new Dimension(600, 250));
		panImg.add(panel_2, BorderLayout.CENTER);
		
		ImageIcon icon = new ImageIcon("images/"+horse.getImagename());
		lblImage = new JLabel();
		panel_2.add(lblImage);
		lblImage.setIcon(icon);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(4, 4, 0, 0));
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 : ");
		panel_1.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		JLabel lblName_ = new JLabel(horse.getName());
		lblName_.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblName_);
		
		JLabel lbl = new JLabel("\uB0A0\uC528\uC5D0 \uB530\uB978");
		lbl.setHorizontalAlignment(SwingConstants.CENTER);
		lbl.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lbl);
		
		JLabel lblNewLabel_5 = new JLabel("\uAE30\uBD84 \uC0C1\uD0DC \uD655\uB960");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_1 = new JLabel("\uB098\uC774 : ");
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		tfAge = new JTextField();
		tfAge.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfAge.setText(horse.getAge()+"");
		panel_1.add(tfAge);
		tfAge.setColumns(10);
		
		JLabel label_1 = new JLabel("\uB9D1\uC74C : ");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_1);
		
		tfSunny = new JTextField();
		tfSunny.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfSunny.setText(hc.getSunny()+"");
		tfSunny.setColumns(10);
		panel_1.add(tfSunny);
		
		JLabel lblNewLabel_2 = new JLabel("\uC2E0\uC7A5(cm) : ");
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		tfCm = new JTextField();
		tfCm.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfCm.setText(horse.getHeight_cm()+"");
		panel_1.add(tfCm);
		tfCm.setColumns(10);
		
		JLabel label_2 = new JLabel("\uD750\uB9BC : ");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_2);
		
		tfCloud = new JTextField();
		tfCloud.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfCloud.setText(hc.getCloud()+"");
		tfCloud.setColumns(10);
		panel_1.add(tfCloud);
		
		JLabel lblNewLabel_3 = new JLabel("\uBB34\uAC8C(kg) : ");
		panel_1.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfKg = new JTextField();
		tfKg.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfKg.setText(horse.getWeight_kg()+"");
		panel_1.add(tfKg);
		tfKg.setColumns(10);
		
		JLabel label_3 = new JLabel("\uBE44 :");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_3);
		
		tfRain = new JTextField();
		tfRain.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfRain.setText(hc.getRain()+"");
		tfRain.setColumns(10);
		panel_1.add(tfRain);
		
		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		contentPane.add(panBtn, BorderLayout.SOUTH);
		
		btnInsert = new JButton("");
		btnInsert.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnInsert.png"));
		btnInsert.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnInsert.png"));
		btnInsert.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnInsert.png"));
		btnInsert.setBorderPainted(false); btnInsert.setFocusPainted(false); btnInsert.setContentAreaFilled(false);
		btnInsert.setBackground(Color.WHITE);
		btnInsert.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnInsert);
		btnInsert.addActionListener(this);
		
		btnReset = new JButton("");
		btnReset.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCancel.png"));
		btnReset.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbbtnReset.png"));
		btnReset.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnReset.png"));
		btnReset.setBorderPainted(false);
		btnReset.setFocusPainted(false);
		btnReset.setContentAreaFilled(false);
		btnReset.setBackground(Color.WHITE);
		btnReset.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnReset);
		btnReset.addActionListener(this);
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false);
		btnClose.setFocusPainted(false);
		btnClose.setContentAreaFilled(false);
		btnClose.setBackground(Color.WHITE);
		btnClose.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnClose);
		btnClose.addActionListener(this);
		
		
		setVisible(true);
	}

	private void tfReset() {
		tfAge.setText("");
		tfCm.setText("");
		tfKg.setText("");
		tfSunny.setText("");
		tfCloud.setText("");
		tfRain.setText("");
	}
	/*
	 * Horse h = new Horse(); int row = table.getSelectedRow();
	 * h.setName(movieList.get(row).getMno()); h.setAge(id);
	 * h.setHeight_Cm(dateCombo.getSelectedItem().toString());
	 * h.setWeight_Kg(Integer.parseInt(tf.getText().toString())); 
	 * HorseDao dao = HorseDao.getInstance();
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		Object obj = e.getSource();
		if (obj == btnInsert) {
			Horse h = new Horse();
			h.setAge(Integer.parseInt(tfAge.getText().toString()));
			h.setHeight_cm(Double.parseDouble(tfCm.getText().toString()));
			h.setWeight_kg(Double.parseDouble(tfKg.getText().toString()));
			h.setName(horse.getName());
			HorseDao dao = HorseDao.getInstance();
			int n = dao.update(h);
			Horse_Condition hc = new Horse_Condition();
			hc.setHno(horse.getHno());
			hc.setSunny(Double.parseDouble(tfSunny.getText()));
			hc.setCloud(Double.parseDouble(tfCloud.getText()));
			hc.setRain(Double.parseDouble(tfRain.getText()));
			Horse_ConditionDao hcdao = Horse_ConditionDao.getInstance();
			int hn = hcdao.update(hc);
			if (n == 1 && hn ==1) {
				JOptionPane.showMessageDialog(null, "���� ����");
				try {
					hr.setUpTableData();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "���� ����");
			}
		} else if (obj == btnReset) {
			tfReset();
		} else if (obj == btnClose) {
			this.dispose();
		}
		try {
			hr.setUpTableData();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.dispose();
	}
}
