package server;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class ServerMain extends JFrame implements ActionListener {

	private JPanel contentPane;
	public static HorseServer server;
	private JButton btnHolesManager;
	private JButton btnPlayManager;
	private JButton btnTicketManager;
	private JButton btnClose;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerMain frame = new ServerMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ServerMain() {
		ImageIcon main = new ImageIcon("images/main.jpg");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 800, 600);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(main.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel panBtn = new JPanel();
		panel_1.add(panBtn, BorderLayout.SOUTH);
		panBtn.setBackground(Color.WHITE);
		panBtn.setPreferredSize(new Dimension(800, 100));
		panBtn.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		btnHolesManager = new JButton("");
		btnHolesManager.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnHM.png"));
		btnHolesManager.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnHM.png"));
		btnHolesManager.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnHM.png"));
		btnHolesManager.setBorderPainted(false); btnHolesManager.setFocusPainted(false); btnHolesManager.setContentAreaFilled(false);
		btnHolesManager.setBackground(Color.WHITE);
		btnHolesManager.setFont(new Font("���� ����", Font.BOLD, 25));
		panBtn.add(btnHolesManager);

		
		btnPlayManager = new JButton("");
		btnPlayManager.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnMatch.png"));
		btnPlayManager.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnMatch.png"));
		btnPlayManager.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnMatch.png"));
		btnPlayManager.setBackground(Color.WHITE);
		btnPlayManager.setFont(new Font("���� ����", Font.BOLD, 25));
		btnPlayManager.setBorderPainted(false); btnPlayManager.setFocusPainted(false); btnPlayManager.setContentAreaFilled(false);
		panBtn.add(btnPlayManager);
		
		btnTicketManager = new JButton("");
		btnTicketManager.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnBatting.png"));
		btnTicketManager.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnBatting.png"));
		btnTicketManager.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnBatting.png"));
		btnTicketManager.setBackground(Color.WHITE);
		btnTicketManager.setFont(new Font("���� ����", Font.BOLD, 25));
		btnTicketManager.setBorderPainted(false); btnTicketManager.setFocusPainted(false); btnTicketManager.setContentAreaFilled(false);
		panBtn.add(btnTicketManager);
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBackground(Color.WHITE);
		btnClose.setFont(new Font("���� ����", Font.BOLD, 25));
		btnClose.setBorderPainted(false); btnClose.setFocusPainted(false); btnClose.setContentAreaFilled(false);
		panBtn.add(btnClose);
		
		btnHolesManager.addActionListener(this);
		btnPlayManager.addActionListener(this);
		btnTicketManager.addActionListener(this);
		btnClose.addActionListener(this);
		server=new HorseServer(this);
		server.startServer();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if(obj == btnHolesManager) {
			try {
				new HorseManager();
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else if(obj == btnPlayManager){
			try {
				new MatchShowGUI();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else if(obj == btnTicketManager){
			try {
				new BettingShowGUI();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else {
			System.out.println("[��������]");
			System.exit(0);
		}
	}
}
