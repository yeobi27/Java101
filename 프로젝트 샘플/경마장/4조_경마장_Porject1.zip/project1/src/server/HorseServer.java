package server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class HorseServer {
	ServerMain ServerMainGUI;
	static Selector selector;
	static ServerSocketChannel serverSocketChannel;
	static List<Client> connections = new Vector<Client>();

	public HorseServer(ServerMain ServerMainGUI) {
		this.ServerMainGUI = ServerMainGUI;
	}

	void startServer() {
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.configureBlocking(false);
			serverSocketChannel.bind(new InetSocketAddress(5100));
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		} catch (Exception e) {
			e.printStackTrace();
			if (serverSocketChannel.isOpen()) {
				stopServer();
			}
			return;
		}

		Thread thread = new Thread() {
			public void run() {
				while (true) {
					try {
						int keyCount = selector.select();
						if (keyCount == 0) {
							continue;
						}
						Set<SelectionKey> selectedKeys = selector.selectedKeys();
						Iterator<SelectionKey> iterator = selectedKeys.iterator();

						while (iterator.hasNext()) { // OP_~~�� Ȱ��ȭ �Ǵ� �κ�
							SelectionKey selectionKey = iterator.next();
							if (selectionKey.isAcceptable()) {
								accept(selectionKey);
							} else if (selectionKey.isReadable()) { // OP_READ �� �� ����
								Client client = (Client) selectionKey.attachment();
								client.receive(selectionKey);
							} else if (selectionKey.isWritable()) { // OP_WRITE �� �� ����
								Client client = (Client) selectionKey.attachment();
								client.send(selectionKey);
							}
							iterator.remove();
						}
					} catch (Exception e) {
						if (serverSocketChannel.isOpen()) {
							stopServer();
						}
						break;
					}
				}
			}
		};
		thread.start();
		System.out.println("[��������]");
	}

	@SuppressWarnings("static-access")
	void stopServer() {
		try {
			Iterator<Client> iterator = connections.iterator();
			while (iterator.hasNext()) {
				Client client = iterator.next();
				client.socketChannel.close();
				iterator.remove();
			}
			if (serverSocketChannel != null && serverSocketChannel.isOpen()) {
				serverSocketChannel.close();
			}
			if (selector != null && selector.isOpen()) {
				selector.close();
			}
			System.out.println("[���� ����]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void accept(SelectionKey selectionKey) {
		try {
			ServerSocketChannel serverSocketChannel = (ServerSocketChannel) selectionKey.channel();
			SocketChannel socketChannel = serverSocketChannel.accept();

			String message = "[���� ����: " + socketChannel.getRemoteAddress() + " : " + Thread.currentThread().getName()
					+ "]";
			System.out.println(message);
			Client client = new Client(socketChannel);
			connections.add(client);
			System.out.println("[���� ����:" + connections.size() + "]");
		} catch (Exception e) {
			if (serverSocketChannel.isOpen()) {
				stopServer();
			}
			e.printStackTrace();
		}
	}

	static class Client {
		static SocketChannel socketChannel;
		String sendData;

		Client(SocketChannel socketChannel) throws IOException {
			this.socketChannel = socketChannel;
			socketChannel.configureBlocking(false);
			SelectionKey selectionKey = socketChannel.register(selector, SelectionKey.OP_READ); // Ŭ���̾�Ʈ������ �������� �켱 ����
																								// ���
			selectionKey.attach(this);
		}

		void receive(SelectionKey selectionKey) { // �������� ���� Ŭ���̾�Ʈ���� �� ó���� ���ݴϴ�
			try {
				ByteBuffer byteBuffer = ByteBuffer.allocate(100); // ����Ʈ���� �Ҵ�
				int byteCount = socketChannel.read(byteBuffer); // ����ä���� ����� �о����� Ȯ��
				String flag = "";
				if (byteCount == -1) {
					throw new IOException();
				}
				String message = "[�������: " + socketChannel.getRemoteAddress() + " : " + Thread.currentThread().getName()
						+ "]";
				System.out.println(message);
				byteBuffer.flip(); // ���� ������ ���� �� ��������
				Charset charset = Charset.forName("MS949");
				String datastr = charset.decode(byteBuffer).toString();
				int data = Integer.parseInt(datastr);
				if (data >= 5) {
					flag = "TRUE";
					new HorseMatch();
				}
				for (Client client : connections) { // ���������͸� ��Ƽ� write�� �����ְ�
					client.sendData = flag;
					SelectionKey key = socketChannel.keyFor(selector);
					key.interestOps(SelectionKey.OP_WRITE);
				}
				selector.wakeup(); // �����͸� ����� send�� ����
			} catch (Exception e) {
				try {
					connections.remove(this);
					String message = "[Ŭ���̾�Ʈ ��� �ȵ�: " + socketChannel.getRemoteAddress() + " : "
							+ Thread.currentThread().getName() + "]";
					System.out.println(message);
					socketChannel.close();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			}
		}

		void send(SelectionKey selectionKey) { // send�� ����Ǹ�
			try {
				Charset charset = Charset.forName("MS949");
				ByteBuffer byteBuffer = charset.encode(sendData);
				System.out.println(sendData);
				socketChannel.write(byteBuffer); // ����ä�ο� �����͸� ������ϴ�
				System.out.println("[������ �Ϸ�]");
				selectionKey.interestOps(SelectionKey.OP_READ); // �׸��� �ٽ� ���۹ޱ����� ���·� �����ϰ�
				selector.wakeup(); // �ٽ� selector�� �������ݴϴ�.
			} catch (Exception e) {
				try {
					String message = "[Ŭ���̾�Ʈ ��� �ȵ�: " + socketChannel.getRemoteAddress() + ": "
							+ Thread.currentThread().getName() + "]";
					System.out.println(message);
					connections.remove(this);
					socketChannel.close();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			}
		}

		static void send(int x, int idx) {
			for (Client client : connections) {
				client.sendData = idx + "," + x;
				SelectionKey key = socketChannel.keyFor(selector);
				key.interestOps(SelectionKey.OP_WRITE);
				selector.wakeup();
			}
		}
	}
}
