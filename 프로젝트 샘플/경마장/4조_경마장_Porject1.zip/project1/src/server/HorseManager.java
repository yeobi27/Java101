package server;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.HorseDao;
import dao.Horse_ConditionDao;
import dto.Horse;
import dto.Horse_Condition;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;

public class HorseManager extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JLabel lblName_;
	private JLabel lblCm_;
	private JLabel lblKg_;
	private JLabel lblOdd_;
	private ArrayList<Horse> horseList;
	private String[] horseInfo = { "��ȣ", "�̸�", "����", "����(cm)", "����(kg)", "�·�" ,"����"};
	private int row = 0;
	private JTable table;
	private Horse h;
	private DefaultTableModel model;
	private JButton btnIns;
	private JButton btnAlt;
	private JButton btnDel;
	private JButton btnCls;
	private JLabel lblAge_;
	private JLabel lblSunny;
	private JLabel lblCloud;
	private JLabel lblRain;
	private JLabel lblD_rate_;
	private JLabel lblImage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new HorseManager();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */
	public HorseManager() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 800, 600);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		horseDB();

		JPanel panelNorth = new JPanel();
		panelNorth.setBackground(Color.WHITE);
		contentPane.add(panelNorth, BorderLayout.NORTH);

		JLabel lblNewLabel = new JLabel("[ \uACBD\uC8FC\uB9C8 \uBA85\uB2E8 ]");
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 25));
		panelNorth.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));

		JPanel panelL = new JPanel();
		panelL.setBackground(Color.WHITE);
		panel_1.add(panelL, BorderLayout.NORTH);
		panelL.setLayout(new BorderLayout(0, 0));

		JScrollPane scrollPane = new JScrollPane(table);
		panelL.setPreferredSize(new Dimension(800, 250));
		panelL.add(scrollPane);

		JPanel panelR = new JPanel();
		panelR.setBackground(Color.WHITE);
		panel_1.add(panelR, BorderLayout.CENTER);
		panelR.setLayout(new BorderLayout(0, 0));

		JPanel panelImg = new JPanel();
		panelImg.setPreferredSize(new Dimension(320, 250));
		panelImg.setBackground(Color.WHITE);
		panelR.add(panelImg, BorderLayout.WEST);

		lblImage = new JLabel("");
		panelImg.add(lblImage);

		JPanel panelInfo = new JPanel();
		panelInfo.setBackground(Color.WHITE);
		panelR.add(panelInfo, BorderLayout.CENTER);

		JPanel panLbl = new JPanel();
		panLbl.setBackground(Color.WHITE);
		panelInfo.add(panLbl, BorderLayout.CENTER);
		panLbl.setLayout(new GridLayout(7, 4, 0, 0));
		
		JLabel label_4 = new JLabel("");
		panLbl.add(label_4);
		
		JLabel label_5 = new JLabel("");
		panLbl.add(label_5);
		
		JLabel label_6 = new JLabel("");
		panLbl.add(label_6);
		
		JLabel label_7 = new JLabel("");
		panLbl.add(label_7);

		JLabel lblName = new JLabel("\uC774\uB984 : ");
		lblName.setHorizontalAlignment(SwingConstants.RIGHT);
		panLbl.add(lblName);
		lblName.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		lblName_ = new JLabel("");
		lblName_.setHorizontalAlignment(SwingConstants.CENTER);
		panLbl.add(lblName_);
		lblName_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		JLabel lblNewLabel_1 = new JLabel("\uB0A0\uC528\uC5D0 \uB530\uB978");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 14));
		panLbl.add(lblNewLabel_1);

		JLabel label = new JLabel("\uAE30\uBD84 \uC88B\uC744 \uD655\uB960");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 14));
		panLbl.add(label);

		JLabel lblAge = new JLabel("\uB098\uC774 : ");
		lblAge.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAge.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panLbl.add(lblAge);

		lblAge_ = new JLabel("");
		lblAge_.setHorizontalAlignment(SwingConstants.CENTER);
		lblAge_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panLbl.add(lblAge_);

		JLabel lblNewLabel_2 = new JLabel("\uB9D1\uC74C : ");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblNewLabel_2);

		lblSunny = new JLabel("");
		lblSunny.setHorizontalAlignment(SwingConstants.CENTER);
		lblSunny.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblSunny);

		JLabel lblCm = new JLabel("\uC2E0\uC7A5(cm) : ");
		lblCm.setHorizontalAlignment(SwingConstants.RIGHT);
		panLbl.add(lblCm);
		lblCm.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		lblCm_ = new JLabel("");
		lblCm_.setHorizontalAlignment(SwingConstants.CENTER);
		panLbl.add(lblCm_);
		lblCm_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		JLabel lblNewLabel_3 = new JLabel("\uD750\uB9BC : ");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblNewLabel_3);

		lblCloud = new JLabel("");
		lblCloud.setHorizontalAlignment(SwingConstants.CENTER);
		lblCloud.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblCloud);

		JLabel lblKg = new JLabel("\uBB34\uAC8C(kg) : ");
		lblKg.setHorizontalAlignment(SwingConstants.RIGHT);
		panLbl.add(lblKg);
		lblKg.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		lblKg_ = new JLabel("");
		lblKg_.setHorizontalAlignment(SwingConstants.CENTER);
		panLbl.add(lblKg_);
		lblKg_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		JLabel lblNewLabel_4 = new JLabel("\uBE44 : ");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblNewLabel_4);

		lblRain = new JLabel("");
		lblRain.setHorizontalAlignment(SwingConstants.CENTER);
		lblRain.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblRain);

		JLabel lblOdd = new JLabel("\uC2B9\uB960 : ");
		lblOdd.setHorizontalAlignment(SwingConstants.RIGHT);
		panLbl.add(lblOdd);
		lblOdd.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		lblOdd_ = new JLabel("");
		lblOdd_.setHorizontalAlignment(SwingConstants.CENTER);
		panLbl.add(lblOdd_);
		lblOdd_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));

		JLabel lblD_rate = new JLabel("\uBC30\uB2F9\uB960 : ");
		lblD_rate.setHorizontalAlignment(SwingConstants.RIGHT);
		lblD_rate.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panLbl.add(lblD_rate);

		lblD_rate_ = new JLabel("");
		lblD_rate_.setHorizontalAlignment(SwingConstants.CENTER);
		lblD_rate_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panLbl.add(lblD_rate_);
		
		JLabel lblNewLabel_5 = new JLabel("");
		panLbl.add(lblNewLabel_5);
		
		JLabel label_1 = new JLabel("");
		panLbl.add(label_1);
		
		JLabel label_2 = new JLabel("");
		panLbl.add(label_2);
		
		JLabel label_3 = new JLabel("");
		panLbl.add(label_3);

		JPanel panelBtn = new JPanel();
		panelR.add(panelBtn, BorderLayout.SOUTH);
		panelBtn.setBackground(Color.WHITE);

		if (horseList.size() != 0) {
			h = horseList.get(row);
			Horse_ConditionDao dao = Horse_ConditionDao.getInstance();
			Horse_Condition hc = dao.SelectOne(h.getHno());
			lblName_.setText(h.getName());
			lblAge_.setText(h.getAge() + "");
			lblCm_.setText(h.getHeight_cm() + "");
			lblKg_.setText(h.getWeight_kg() + "");
			lblOdd_.setText(h.getOdds() + "");
			lblD_rate_.setText(h.getDividend_rate() + "");
			lblSunny.setText(hc.getSunny()+"");
			lblCloud.setText(hc.getCloud()+"");
			lblRain.setText(hc.getRain()+"");
			File file = new File("images/"+h.getImagename());
			Image resizeImage = Image_resize(file);
			lblImage.setIcon(new ImageIcon(resizeImage));
		}

		btnIns = new JButton("");
		btnIns.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnInsert.png"));
		btnIns.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnInsert.png"));
		btnIns.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnInsert.png"));
		btnIns.setBorderPainted(false);
		btnIns.setFocusPainted(false);
		btnIns.setContentAreaFilled(false);
		btnIns.setBackground(Color.WHITE);
		panelBtn.add(btnIns);
		btnIns.addActionListener(this);

		btnAlt = new JButton("");
		btnAlt.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnUpdate.png"));
		btnAlt.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnUpdate.png"));
		btnAlt.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnUpdate.png"));
		btnAlt.setBorderPainted(false);
		btnAlt.setFocusPainted(false);
		btnAlt.setContentAreaFilled(false);
		btnAlt.setBackground(Color.WHITE);
		panelBtn.add(btnAlt);
		btnAlt.addActionListener(this);

		btnDel = new JButton("");
		btnDel.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnDelete.png"));
		btnDel.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnDelete.png"));
		btnDel.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnDelete.png"));
		btnDel.setBorderPainted(false);
		btnDel.setFocusPainted(false);
		btnDel.setContentAreaFilled(false);
		btnDel.setBackground(Color.WHITE);
		panelBtn.add(btnDel);
		btnDel.addActionListener(this);

		btnCls = new JButton("");
		btnCls.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnCls.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnCls.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnCls.setBorderPainted(false);
		btnCls.setFocusPainted(false);
		btnCls.setContentAreaFilled(false);
		btnCls.setBackground(Color.WHITE);
		panelBtn.add(btnCls);
		btnCls.addActionListener(this);

		setVisible(true);
	}

	private Image Image_resize(File file) {
		// TODO Auto-generated method stub
		Image image = null;
		int imageW, imageH;
		int w= 0, h= 0;
		double ratio;
		int newW = 320;
		
		try {
			image = ImageIO.read(file);
			
			imageW = image.getWidth(null);
			imageH = image.getHeight(null);
			
			ratio = (double)newW/(double)imageW;
			w = (int)(imageW*ratio);
			h = (int)(imageH*ratio);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Image resizeImage = image.getScaledInstance(w, h, Image.SCALE_SMOOTH);
		return resizeImage;
	}

	private void horseDB() throws Exception {
		HorseDao dao = HorseDao.getInstance();
		horseList = dao.selectAll();
		DefaultTableModel tm = new DefaultTableModel(horseInfo, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				if (column >= 0)
					return false;
				else
					return true;
			}
		};
		Object[] obj = new Object[7];
		for (int i = 0; i < horseList.size(); i++) {
			Horse h = horseList.get(i);
			obj[0] = h.getHno();
			obj[1] = h.getName();
			obj[2] = h.getAge();
			obj[3] = h.getHeight_cm();
			obj[4] = h.getWeight_kg();
			obj[5] = h.getOdds();
			obj[6] = h.getDividend_rate();
			tm.addRow(obj);
		}
		table = new JTable(tm);
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				if (e.getClickCount() == 1) {
					row = table.getSelectedRow();
					lblSet(row);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
	}

	private void lblSet(int row) {
		Horse horse = horseList.get(row);
		Horse_ConditionDao dao = Horse_ConditionDao.getInstance();
		Horse_Condition hc = dao.SelectOne(horse.getHno());
		// ImageIcon icon = new ImageIcon("images/" + holes.getImage_name());
		// lblThumb.setIcon(icon);=
		lblName_.setText(horse.getName());
		lblAge_.setText(horse.getAge() + "");
		lblCm_.setText(horse.getHeight_cm() + "");
		lblKg_.setText(horse.getWeight_kg() + "");
		lblOdd_.setText(horse.getOdds() + "");		
		lblD_rate_.setText(horse.getDividend_rate() + "");
		lblSunny.setText(hc.getSunny()+"");
		lblCloud.setText(hc.getCloud()+"");
		lblRain.setText(hc.getRain()+"");
		File file = new File("images/"+horse.getImagename());
		Image resizeImage = Image_resize(file);
		lblImage.setIcon(new ImageIcon(resizeImage));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// ��ư ���ý� �׿� �´� ��� ����.
		Object obj = e.getSource();
		if (obj == btnIns) {
			try {
				new HorseInsert(this);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (obj == btnAlt) {
			try {
				Horse horse = horseList.get(row);
				Horse_ConditionDao dao = Horse_ConditionDao.getInstance();
				Horse_Condition hc = dao.SelectOne(horse.getHno());
				new HorseUpdate(horse, hc, this);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (obj == btnDel) {
			int row = table.getSelectedRow();
			Horse h = horseList.get(row);
			System.out.println(h);
			HorseDao dao = HorseDao.getInstance();
			int n = dao.delete(h.getHno());
			if (n == 1) {
				JOptionPane.showMessageDialog(null, "���� ����");
			} else {
				JOptionPane.showMessageDialog(null, "���� ����");
			}
			try {
				setUpTableData();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			dispose();
		}
	}

	// ��������� ��ũ�ѻ� �����Ͽ� ǥ��.
	public void setUpTableData() throws Exception {
		HorseDao dao = HorseDao.getInstance();
		model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		horseList = dao.selectAll();
		Object[] obj = new Object[7];
		for (int i = 0; i < horseList.size(); i++) {
			Horse h = horseList.get(i);
			obj[0] = h.getHno();
			obj[1] = h.getName();
			obj[2] = h.getAge();
			obj[3] = h.getHeight_cm();
			obj[4] = h.getWeight_kg();
			obj[5] = h.getOdds();
			obj[6] = h.getDividend_rate();
			model.addRow(obj);
		}
		model.fireTableDataChanged();
	}
}
