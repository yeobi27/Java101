package server;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.BettingDao;
import dto.Betting;
import dto.Betting2;
import javax.swing.ImageIcon;
import java.awt.Color;

public class BettingShowGUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private ArrayList<Betting2> betList;
	private String[] betInfo = { "��ȣ", "�� ��ȣ", "�� �̸�", "ȸ�� ��ȣ", "ȸ���̸�", "���ñݾ�" };
	private JTable table;
	private JButton btnClose;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//new BettingShowGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */
	public BettingShowGUI() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 600, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		BettingDB();

		JPanel panelNorth = new JPanel();
		panelNorth.setBackground(Color.WHITE);
		contentPane.add(panelNorth, BorderLayout.NORTH);
		panelNorth.setLayout(new BorderLayout(0, 0));

		JPanel panLbl = new JPanel();
		panLbl.setBackground(Color.WHITE);
		panelNorth.add(panLbl, BorderLayout.CENTER);

		JLabel lblNewLabel = new JLabel("[ \uB9C8\uAD8C \uB9AC\uC2A4\uD2B8 ]");
		panLbl.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 30));

		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panelNorth.add(panBtn, BorderLayout.EAST);

		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false);
		btnClose.setFocusPainted(false);
		btnClose.setContentAreaFilled(false);
		btnClose.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnClose);
		btnClose.addActionListener(this);

		JPanel panTable = new JPanel();
		panTable.setBackground(Color.WHITE);
		contentPane.add(panTable, BorderLayout.CENTER);
		panTable.setLayout(new BorderLayout(0, 0));

		JScrollPane scrollPane = new JScrollPane(table);
		panTable.add(scrollPane, BorderLayout.CENTER);

		setVisible(true);
	}

	private void BettingDB() throws Exception {
		BettingDao dao = BettingDao.getInstance();
		betList = dao.selectInfo();
		DefaultTableModel tm = new DefaultTableModel(betInfo, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				if (column >= 0)
					return false;
				else
					return true;
			}
		};
		Object[] obj = new Object[6];
		for (int i = 0; i < betList.size(); i++) {
			Betting2 b = betList.get(i);
			obj[0] = b.getBno();
			obj[1] = b.getHno();
			obj[2] = b.getHname();
			obj[3] = b.getMno();
			obj[4] = b.getMid();
			obj[5] = b.getBet_money();
			tm.addRow(obj);
		}
		table = new JTable(tm);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// ��ư ���ý� �׿� �´� ��� ����.
		Object obj = e.getSource();
		if (obj == btnClose)
			dispose();
	}
}
