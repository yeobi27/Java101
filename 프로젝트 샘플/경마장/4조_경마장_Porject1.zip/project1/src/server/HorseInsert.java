package server;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

import dao.HorseDao;
import dao.Horse_ConditionDao;
import dto.Horse;
import dto.Horse_Condition;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;

public class HorseInsert extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField tfName;
	private JTextField tfAge;
	private JTextField tfCm;
	private JTextField tfKg;
	private HorseManager hr;
	private int row = 0;
	private JTextField tfSunny;
	private JTextField tfCloud;
	private JTextField tfRain;
	private JButton btnClose;
	private JButton btnCancel;
	private JButton btnInsert;
	private JButton btnUpload;
	private JLabel lblImage;
	public String filename;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//HorseInsert frame = new HorseInsert();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HorseInsert(HorseManager hr) {
		this.hr=hr;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 600, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
				
		JLabel label = new JLabel("[\uC2E0\uADDC \uB9D0 \uB4F1\uB85D]");
		label.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 35));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(label, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panImg = new JPanel();
		panel.add(panImg, BorderLayout.NORTH);
		panImg.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setPreferredSize(new Dimension(600, 250));
		panImg.add(panel_2, BorderLayout.CENTER);
		
		ImageIcon icon = new ImageIcon("images/iconReset.png");
		lblImage = new JLabel("");
		panel_2.add(lblImage);
		lblImage.setIcon(icon);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panImg.add(panel_3, BorderLayout.SOUTH);
		
		btnUpload = new JButton("");
		btnUpload.setPreferredSize(new Dimension(150, 50));
		btnUpload.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnUpload.png"));
		btnUpload.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnUpload.png"));
		btnUpload.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnUpload.png"));
		btnUpload.setBorderPainted(false);
		btnUpload.setFocusPainted(false);
		btnUpload.setContentAreaFilled(false);
		panel_3.add(btnUpload);
		btnUpload.addActionListener(new OpenActionListener());
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(4, 4, 0, 0));
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 : ");
		panel_1.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		
		tfName = new JTextField();
		tfName.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfName);
		tfName.setColumns(10);
		
		JLabel lbl = new JLabel("\uB0A0\uC528\uC5D0 \uB530\uB978");
		lbl.setHorizontalAlignment(SwingConstants.CENTER);
		lbl.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lbl);
		
		JLabel lblNewLabel_5 = new JLabel("\uAE30\uBD84 \uC88B\uC744 \uD655\uB960");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_1 = new JLabel("\uB098\uC774 : ");
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		tfAge = new JTextField();
		tfAge.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfAge);
		tfAge.setColumns(10);
		
		JLabel label_1 = new JLabel("\uB9D1\uC74C : ");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_1);
		
		tfSunny = new JTextField();
		tfSunny.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfSunny.setColumns(10);
		panel_1.add(tfSunny);
		
		JLabel lblNewLabel_2 = new JLabel("\uC2E0\uC7A5(cm) : ");
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		
		tfCm = new JTextField();
		tfCm.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfCm);
		tfCm.setColumns(10);
		
		JLabel label_2 = new JLabel("\uD750\uB9BC : ");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_2);
		
		tfCloud = new JTextField();
		tfCloud.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfCloud.setColumns(10);
		panel_1.add(tfCloud);
		
		JLabel lblNewLabel_3 = new JLabel("\uBB34\uAC8C(kg) : ");
		panel_1.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfKg = new JTextField();
		tfKg.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfKg);
		tfKg.setColumns(10);
		
		JLabel label_3 = new JLabel("\uBE44 :");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(label_3);
		
		tfRain = new JTextField();
		tfRain.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfRain.setColumns(10);
		panel_1.add(tfRain);
		
		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		contentPane.add(panBtn, BorderLayout.SOUTH);
		
		btnInsert = new JButton("");
		btnInsert.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnInsert.png"));
		btnInsert.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnInsert.png"));
		btnInsert.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnInsert.png"));
		btnInsert.setBorderPainted(false); btnInsert.setFocusPainted(false); btnInsert.setContentAreaFilled(false);
		btnInsert.setBackground(Color.WHITE);
		btnInsert.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnInsert);
		btnInsert.addActionListener(this);
		
		btnCancel = new JButton("");
		btnCancel.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCancel.png"));
		btnCancel.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCancel.png"));
		btnCancel.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCancel.png"));
		btnCancel.setBorderPainted(false);
		btnCancel.setFocusPainted(false);
		btnCancel.setContentAreaFilled(false);
		btnCancel.setBackground(Color.WHITE);
		btnCancel.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnCancel);
		btnCancel.addActionListener(this);
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false);
		btnClose.setFocusPainted(false);
		btnClose.setContentAreaFilled(false);
		btnClose.setBackground(Color.WHITE);
		btnClose.setPreferredSize(new Dimension(150, 50));
		panBtn.add(btnClose);
		btnClose.addActionListener(this);
		
		
		setVisible(true);
	}


	class OpenActionListener implements ActionListener {
		private JFileChooser chooser;
		public OpenActionListener() {
			chooser = new JFileChooser();
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF Images","jpg","gif");
			chooser.setFileFilter(filter);
			int ret = chooser.showOpenDialog(null);
			if(ret != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(null, "������ �������� �ʾҽ��ϴ�", "���", JOptionPane.WARNING_MESSAGE);
				return;
			}
			String filePath = chooser.getSelectedFile().getPath();
			filename = filePath.substring(filePath.lastIndexOf("\\")+1,filePath.lastIndexOf("."));
			File src = new File(filePath);
			File dest  = new File("images/"+filename+".jpg");
			
			int newH = 250;
			Image image;
			int imageW, imageH;
			double ratio;
			int w, h;
			try {
				image = ImageIO.read(src);
				
				imageW = image.getWidth(null);
				imageH = image.getHeight(null);
				
				ratio = (double)newH/(double)imageH;
				w = (int)(imageW*ratio);
				h = (int)(imageH*ratio);
				
				Image resiezeImage = image.getScaledInstance(w,h,Image.SCALE_SMOOTH);
				
				BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				Graphics g = newImage.getGraphics();
				g.drawImage(resiezeImage, 0, 0, null);
				g.dispose();
				ImageIO.write(newImage, "jpg", dest);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			filename = dest.getPath().substring(7);
			
			lblImage.setIcon(new ImageIcon("images/"+filename));
			//pack();
		}

	}
	private void tfReset() {
		ImageIcon icon = new ImageIcon("images/iconReset.png");
		lblImage.setIcon(icon);
		tfName.setText("");
		tfAge.setText("");
		tfCm.setText("");
		tfKg.setText("");
		tfSunny.setText("");
		tfCloud.setText("");
		tfRain.setText("");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		hr.setVisible(false);
		Object obj = e.getSource();
		if (obj==btnInsert) {
			Horse h = new Horse();
			Horse_Condition hc = new Horse_Condition();
			h.setName(tfName.getText());
			h.setAge(Integer.parseInt(tfAge.getText()));
			h.setHeight_cm(Double.parseDouble(tfCm.getText()));
			h.setWeight_kg(Double.parseDouble(tfKg.getText()));
			h.setImagename(filename);
			HorseDao dao = HorseDao.getInstance();
			int n = dao.insert(h);
			h = dao.SelectOne(tfName.getText());
			hc.setHno(h.getHno());
			hc.setSunny(Double.parseDouble(tfSunny.getText()));
			hc.setCloud(Double.parseDouble(tfCloud.getText()));
			hc.setRain(Double.parseDouble(tfRain.getText()));
			Horse_ConditionDao hcdao = Horse_ConditionDao.getInstance();
			int hn = hcdao.insert(hc);
			if (n == 1 && hn==1) {
				JOptionPane.showMessageDialog(null, "��� ����");
				try {
					hr.setUpTableData();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(null, "��� ����");
			}
		}else if (obj == btnCancel) {
			tfReset();
		}else if (obj == btnClose) {
			this.dispose();
		}
		this.dispose();
		hr.repaint();
		hr.setVisible(true);
	}
}
