package server;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.text.ChangedCharSetException;

import dao.BettingDao;
import dao.HorseDao;
import dao.Horse_ConditionDao;
import dao.MatchDao;
import dao.MemberDao;
import dto.Horse;
import dto.Horse_Condition;
import dto.Match;
import dto.Match2;
import dto.Member;

import java.awt.*;
import java.util.ArrayList;

public class HorseMatch extends JFrame implements ActionListener {

	private JPanel contentPane;
	private static String[] weatherof = { "����", "�帲", "��" };
	private ArrayList<Horse> horseList;
	private ArrayList<Horse_Condition> condiList;
	private String[] condi;
	private JButton btnClose;
	public static JLabel[] lblHorse;
	public static int no1 = 0;
	public static int cnt = 0;
	public static int finishcnt = 0;
	public static boolean flag = false;
	static String weather;
	public static Horse_Matching myThread;
	public static Thread th;
	public static boolean stopped = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					weather = weatherof[(int) Math.random() * 3];
					new HorseMatch();
					// frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */
	public HorseMatch() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 800, 600);
		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));

		JPanel panLbl = new JPanel();
		panLbl.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		panLbl.setBackground(Color.WHITE);
		panel.add(panLbl, BorderLayout.CENTER);

		JLabel lbl = new JLabel("\uACBD\uB9C8 \uB300\uD68C");
		lbl.setBackground(Color.WHITE);
		lbl.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 27));
		panLbl.add(lbl);

		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panel.add(panBtn, BorderLayout.EAST);
		panBtn.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));

		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false);
		btnClose.setFocusPainted(false);
		btnClose.setContentAreaFilled(false);
		panBtn.add(btnClose);
		btnClose.addActionListener(this);

		ImageIcon match_back = new ImageIcon("images/match_back.png");
		JPanel panHorse = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(match_back.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		contentPane.add(panHorse, BorderLayout.CENTER);
		panHorse.setLayout(null);

		Condition_Set();
		lblHorse = new JLabel[horseList.size()];
		ImageIcon icon = new ImageIcon("images/horse1.png");
		int y = 0;
		for (int i = 0; i < horseList.size(); i++) {
			lblHorse[i] = new JLabel(icon);
			lblHorse[i].setBounds(0, y, 80, 50);
			panHorse.add(lblHorse[i]);
			y += 85;
		}
		setVisible(true);

		HorseThread(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == btnClose) {
			dispose();
		}
	}

	public void Condition_Set() throws Exception {
		HorseDao hdao = HorseDao.getInstance();
		Horse_ConditionDao hcdao = Horse_ConditionDao.getInstance();

		horseList = hdao.selectAll();
		condiList = hcdao.selectAll();
		condi = new String[horseList.size()];
		for (int i = 0; i < horseList.size(); i++) {
			double rnd = Math.random();
			if (rnd >= (1 - condiList.get(i).getSunny())) {
				condi[i] = "����";
			} else if (rnd >= (1 - condiList.get(i).getCloud())) {
				condi[i] = "����";
			} else
				condi[i] = "����";
		}

	}

	public void HorseThread(HorseMatch hm) {
		myThread = null;
		
		for (int i = 0; i < horseList.size(); i++) {
			myThread = new Horse_Matching(hm, i, horseList.get(i).getHno(), new Rank(), condi[i]);
			th = new Thread(myThread);
			th.start();
			if(stopped==true) {
				try {
					th.interrupt();
					th.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void Betting_Delete() {
		BettingDao bdao = BettingDao.getInstance();

		int n = bdao.deleteAll();
		bdao.createSeq();
		if (n == 1) {
			//JOptionPane.showMessageDialog(null, "������ �ʱ�ȭ�Ͽ����ϴ�.");
		}
	}

	public static void Match_Insert() {
		HorseDao hdao = HorseDao.getInstance();
		MatchDao mdao = MatchDao.getInstance();
		BettingDao bdao = BettingDao.getInstance();
		MemberDao mem = MemberDao.getInstance();
		Match2 m = new Match2();
		Horse h = new Horse();
		h = hdao.SelectOne(no1);
		int totsalemoney = bdao.totSaleMoney();
		int div_money = (int)(totsalemoney * 0.72);
		double d_rate = bdao.hitMoney(h.getHno())/(double)div_money;
		m.setHno(no1);
		m.setHname(h.getName());
		m.setDividend_rate(d_rate);
		int n = mdao.insert(m);
		h.setDividend_rate(d_rate);
		
		try {
			ArrayList<Member> member = mem.selectAll();
			for(int i=0; i<member.size();i++) {
				Member me = new Member();
				me = member.get(i);
				int divM = bdao.SaleMoneyOne(me.getMno(), no1);
				if(divM != 0) {
					int insertdivM = (int)(divM * d_rate);
					me.setDiv_money(insertdivM);
					mem.div_money(me);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int hn = hdao.updateD_rate(h);
		if (n == 1 && hn == 1) {
			JOptionPane.showMessageDialog(null, "��� ����� ��ϵǾ����ϴ�.");
		} else {
			JOptionPane.showMessageDialog(null, "��� ��� ��Ͽ� �����Ͽ����ϴ�.");
		}
	}
	
}

class Horse_Matching implements Runnable {
	private int x;
	private int hno;
	private int length = 680;
	protected static int count = 1;
	private Rank rank;
	private String con;
	private int ino;
	HorseMatch hm;
	

	public Horse_Matching() {
	}

	public Horse_Matching(HorseMatch horse, int ino, int hno, Rank rank, String con) {
		this.hm = horse;
		this.ino = ino;
		this.hno = hno;
		this.rank = rank;
		this.con = con;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			while (!HorseMatch.stopped) {
				Thread.sleep((int) (Math.random() * 200 + 1));
				switch (con) {
				case "����":
					length -= 15;
					x = 15;
					break;
				case "����":
					length -= 10;
					x = 10;
					break;
				case "����":
					length -= 5;
					x = 5;
					break;
				}
				Point p = HorseMatch.lblHorse[ino].getLocation();
				HorseMatch.lblHorse[ino].setBounds(p.x + x, p.y, 80, 50);
				HorseMatch.cnt++;
				if (HorseMatch.cnt < 6) {
					ImageIcon icon = new ImageIcon("images/horse" + (HorseMatch.cnt + 1) + ".png");
					HorseMatch.lblHorse[ino].setIcon(icon);
				} else {
					HorseMatch.cnt = 0;
					ImageIcon icon = new ImageIcon("images/horse1.png");
					HorseMatch.lblHorse[ino].setIcon(icon);
				}
				HorseServer.Client.send(x, ino);
				if (length < 0) {
					this.rank.finishLine(hno);
					if(HorseMatch.finishcnt==HorseMatch.lblHorse.length) {
						HorseMatch.Match_Insert();
						HorseMatch.Betting_Delete();
						hm.dispose();
					}
					break;
				}
				
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			HorseMatch.myThread = null;
			HorseMatch.th = null;
		}
	}
	
	public void stop() {
		HorseMatch.stopped=true;
	}
}

class Rank {
	int rank;

	public Rank() {
	}

	public void finishLine(int hno) {
		// TODO Auto-generated method stub
		rank = Horse_Matching.count++;
		HorseMatch.finishcnt++;
		System.out.println(hno + "�� �� " + rank + "������ ����� ����");
		if (rank == 1) {
			JOptionPane.showMessageDialog(null, "1��� " + hno + "�� ���Դϴ� !!");
			HorseMatch.no1 = hno;
		}
		if (rank == HorseMatch.lblHorse.length) {
			rank = 0;
		}
	}
}
