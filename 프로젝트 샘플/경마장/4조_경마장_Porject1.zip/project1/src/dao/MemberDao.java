package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.Member;

public class MemberDao {
	private MemberDao() {}
	private static MemberDao instance = new MemberDao();

	public static MemberDao getInstance() {
		return instance;
	}
	
	public ArrayList<Member> selectAll() throws Exception {
		ArrayList<Member> res = new ArrayList<Member>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from member";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Member m = new Member();
				m.setMno(rs.getInt(1));
				m.setId(rs.getString(2));
				m.setPassword(rs.getString(3));
				m.setName(rs.getString(4));
				m.setTel(rs.getString(5));
				m.setMoney(rs.getInt(6));
				res.add(m);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public Member SelectOne(String id) {
		Member res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from member where id=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Member m = new Member();
				m.setMno(rs.getInt(1));
				m.setId(rs.getString(2));
				m.setPassword(rs.getString(3));
				m.setName(rs.getString(4));
				m.setTel(rs.getString(5));
				m.setMoney(rs.getInt(6));
				m.setDiv_money(rs.getInt(7));
				res= m;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int insert(Member m) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into member(mno, id, password, name, tel) values(mno_seq.nextval, ?, ?, ?, ?)";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPassword());
			pstmt.setString(3, m.getName());
			pstmt.setString(4, m.getTel());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public int update(Member m) {
		int n=-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update member set password=?, name=?, tel=?, money=? where id=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getPassword());
			pstmt.setString(2, m.getName());
			pstmt.setString(3, m.getTel());
			pstmt.setInt(4, m.getMoney());
			pstmt.setString(5, m.getId());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}

	public void delete(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from member where id=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
	}

	public int userConfirm(String id, String pw) {
		int n=-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select password from member where id=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(pw.equals(rs.getString(1))) n = 1;
				else n = 0;
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return n;
	}
	
	public int idCheck(String id) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id from member where id=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				n=1;
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return n;
	}
	
	public String IdS(String name, String tel) {
		String id="null";
		System.out.println(name+", "+tel);
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id from member where name=? and tel=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, tel);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				id=rs.getString("id");
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return id;
	}
	
	public String PwS(String id, String name, String tel) {
		String pw="null";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select password from member where id=? and name=? and tel=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, tel);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				pw=rs.getString("password");
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return pw;
	}
	
	public void Charging(String id, int money) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update member set money=? where id=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, money);
			pstmt.setString(2, id);
			pstmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt);
		}
	}
	
	public int div_money(Member m) {
		int n =-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update member set div_money=? where mno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, m.getDiv_money());
			pstmt.setInt(2, m.getMno());
			n = pstmt.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public void Alloc(String id) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		String sql = "update member set money=money+div_money where id=?";
		String sql2 = "update member set div_money=0 where id=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt2 = conn.prepareStatement(sql2);
			pstmt.setString(1, id);
			pstmt2.setString(1, id);
			pstmt.executeUpdate();
			pstmt2.executeUpdate();
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				pstmt2.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.close(conn, pstmt);
		}
	}
}