package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.Horse;

public class HorseDao {
	private HorseDao() {}
	private static HorseDao instance = new HorseDao();

	public static HorseDao getInstance() {
		return instance;
	}
	
	public ArrayList<Horse> selectAll() throws Exception {
		ArrayList<Horse> res = new ArrayList<Horse>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from Horse order by hno";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Horse h = new Horse();
				h.setHno(rs.getInt(1));
				h.setName(rs.getString(2));
				h.setAge(rs.getInt(3));
				h.setHeight_cm(rs.getDouble(4));
				h.setWeight_kg(rs.getDouble(5));
				h.setImagename(rs.getString(6));
				h.setOdds(rs.getDouble(7));
				h.setDividend_rate(rs.getDouble(8));
				res.add(h);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public Horse SelectOne(int hno) {
		Horse res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from Horse where hno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Horse h = new Horse();
				h.setHno(rs.getInt(1));
				h.setName(rs.getString(2));
				h.setAge(rs.getInt(3));
				h.setHeight_cm(rs.getDouble(4));
				h.setWeight_kg(rs.getDouble(5));
				h.setImagename(rs.getString(6));
				h.setOdds(rs.getDouble(7));
				h.setDividend_rate(rs.getDouble(8));
				res = h;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	public Horse SelectOne(String name) {
		Horse res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from Horse where name=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Horse h = new Horse();
				h.setHno(rs.getInt(1));
				h.setName(rs.getString(2));
				h.setAge(rs.getInt(3));
				h.setHeight_cm(rs.getDouble(4));
				h.setWeight_kg(rs.getDouble(5));
				h.setImagename(rs.getString(6));
				h.setOdds(rs.getDouble(7));
				h.setDividend_rate(rs.getDouble(8));
				res = h;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int insert(Horse h) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into Horse values(hno_seq.nextval, ?, ?, ?, ?, ?,0,2)";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, h.getName());
			pstmt.setInt(2, h.getAge());
			pstmt.setDouble(3, h.getHeight_cm());
			pstmt.setDouble(4, h.getWeight_kg());
			pstmt.setString(5, h.getImagename());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public int update(Horse h) {
		int n =-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update Horse set age=?, height_cm=?, weight_kg=? where name=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, h.getAge());
			pstmt.setDouble(2, h.getHeight_cm());
			pstmt.setDouble(3, h.getWeight_kg());
			pstmt.setString(4, h.getName());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public int updateD_rate(Horse h) {
		int n =-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update Horse set dividend_rate=? where hno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setDouble(1, h.getDividend_rate());
			pstmt.setDouble(2, h.getHno());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}

	public int delete(int hno) {
		int n=-1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from Horse where hno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			n=pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}

}
