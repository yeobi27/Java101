package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBConnection {
	public static Connection getConnection() throws Exception {
		System.out.println("DB���� ����");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "project1", "1234");
	}

	/*public static Connection getConnection(String ip, int port, String db, String user, String pw) throws Exception{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		return DriverManager.getConnection("jdbc:oracle:thin:@" + ip + ":" + port + ":" + db, user, pw);
	}*/
	public static void close(Connection c, PreparedStatement p) {
		try {
			if (p != null) p.close();
			if (c != null) c.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void close(Connection c, PreparedStatement p, ResultSet r) {
		try {
			if (p != null) p.close();
			if (c != null) c.close();
			if (r != null) r.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}