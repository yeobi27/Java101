package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.Betting;
import dto.Betting2;

public class BettingDao {
	private BettingDao() {}
	private static BettingDao instance = new BettingDao();

	public static BettingDao getInstance() {
		return instance;
	}
	
	public ArrayList<Betting> selectAll() throws Exception {
		ArrayList<Betting> res = new ArrayList<Betting>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from bettings";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Betting b = new Betting();
				b.setBno(rs.getInt(1));
				b.setHno(rs.getInt(2));
				b.setMno(rs.getInt(3));
				b.setBet_money(rs.getInt(4));
				res.add(b);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public Betting SelectOne(int bno) {
		Betting res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from betting where bno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Betting b = new Betting();
				b.setBno(rs.getInt(1));
				b.setHno(rs.getInt(2));
				b.setMno(rs.getInt(3));
				b.setBet_money(rs.getInt(4));
				res = b;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public ArrayList<Betting2> selectInfo() throws Exception {
		ArrayList<Betting2> res = new ArrayList<Betting2>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select bno, b.hno, h.name, b.mno, m.id, bet_money from betting b, horse h, member m where h.hno=b.hno and m.mno=b.mno order by bno asc";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Betting2 b = new Betting2();
				b.setBno(rs.getInt(1));
				b.setHno(rs.getInt(2));
				b.setHname(rs.getString(3));
				b.setMno(rs.getInt(4));
				b.setMid(rs.getString(5));
				b.setBet_money(rs.getInt(6));
				res.add(b);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int insert(Betting b) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into betting values(bno_seq.nextval, ?, ?, ?)";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b.getHno());
			pstmt.setInt(2, b.getMno());
			pstmt.setInt(3, b.getBet_money());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public void update(Betting b) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update betting set hno=?, mno=?, bet_money=? where bno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b.getHno());
			pstmt.setInt(2, b.getMno());
			pstmt.setInt(3, b.getBet_money());
			pstmt.setInt(4, b.getBno());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
	}

	public void delete(int bno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from betting where bno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
	}
	
	public int count() {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from betting";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return cnt;
	}
	
	public int deleteAll() {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from betting";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	public void createSeq() {
		Connection conn = null;
		PreparedStatement pstmt1 =null;
		PreparedStatement pstmt2 =null;
		String dropSql = "drop sequence bno_seq";
		String crateSql = "CREATE SEQUENCE BNO_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 10";
		try {
			conn = DBConnection.getConnection();
			pstmt1 = conn.prepareStatement(dropSql);
			pstmt2 = conn.prepareStatement(crateSql);
			pstmt1.executeUpdate();
			pstmt2.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt1);
			try {
				pstmt2.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public int totSaleMoney() {
		int sum = 0;
		Connection conn = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		String sql = "select sum(bet_money) from betting";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				sum = rs.getInt(1);
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return sum;
	}
	
	public int SaleMoneyOne(int mno, int hno) {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		String sql = "select sum(bet_money) from betting b, horse h where b.hno=h.hno and b.mno=? and b.hno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mno);
			pstmt.setInt(2, hno);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}else {
				result = 0;
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return result;
	}
	public int hitMoney(int hno) {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		String sql = "select sum(bet_money) from betting b, horse h where b.hno=h.hno and b.hno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return result;
	}
}
