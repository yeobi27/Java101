package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.Horse_Condition;

public class Horse_ConditionDao {
	private Horse_ConditionDao() {}
	private static Horse_ConditionDao instance = new Horse_ConditionDao();

	public static Horse_ConditionDao getInstance() {
		return instance;
	}
	
	public ArrayList<Horse_Condition> selectAll() throws Exception {
		ArrayList<Horse_Condition> res = new ArrayList<Horse_Condition>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from Horse_Condition";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Horse_Condition hc = new Horse_Condition();
				hc.setHno(rs.getInt(1));
				hc.setSunny(rs.getDouble(2));
				hc.setCloud(rs.getDouble(3));
				hc.setRain(rs.getDouble(4));
				res.add(hc);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public Horse_Condition SelectOne(int bno) {
		Horse_Condition res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from Horse_Condition where hno=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Horse_Condition hc = new Horse_Condition();
				hc.setHno(rs.getInt(1));
				hc.setSunny(rs.getDouble(2));
				hc.setCloud(rs.getDouble(3));
				hc.setRain(rs.getDouble(4));
				res = hc;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int insert(Horse_Condition hc) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into Horse_Condition values(?, ?, ?, ?)";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hc.getHno());
			pstmt.setDouble(2, hc.getSunny());
			pstmt.setDouble(3, hc.getCloud());
			pstmt.setDouble(4, hc.getRain());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public int update(Horse_Condition hc) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update Horse_Condition set sunny=?, cloud=?, rain=? where hno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setDouble(1, hc.getSunny());
			pstmt.setDouble(2, hc.getCloud());
			pstmt.setDouble(3, hc.getRain());
			pstmt.setInt(4, hc.getHno());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}

	public void delete(int hno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from Horse_Condition where hno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
	}
}
