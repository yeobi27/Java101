package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.Match2;
import dto.Match;
import dto.Match2;

public class MatchDao {
	private MatchDao() {}
	private static MatchDao instance = new MatchDao();

	public static MatchDao getInstance() {
		return instance;
	}
	
	public ArrayList<Match> selectAll() throws Exception {
		ArrayList<Match> res = new ArrayList<Match>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from Match";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Match m = new Match();
				m.setMatch_no(rs.getInt(1));
				m.setHno(rs.getInt(2));
				m.setDividend_rate(rs.getDouble(3));
				res.add(m);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public Match SelectOne(int match_no) {
		Match res = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from Match where match_no=?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, match_no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Match m = new Match();
				m.setMatch_no(rs.getInt(1));
				m.setHno(rs.getInt(2));
				m.setDividend_rate(rs.getDouble(3));
				res = m;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int insert(Match2 m) {
		int n = -1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into Match values(match_no_seq.nextval, ?, ?, ?)";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, m.getHno());
			pstmt.setString(2, m.getHname());
			pstmt.setDouble(3, m.getDividend_rate());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt);
		}
		return n;
	}
	
	public ArrayList<Match2> selectInfo() throws Exception {
		ArrayList<Match2> res = new ArrayList<Match2>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select match_no, m.hno, h.name, m.dividend_rate from match m, horse h where h.hno=m.hno";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Match2 m = new Match2();
				m.setMatch_no(rs.getInt(1));
				m.setHno(rs.getInt(2));
				m.setHname(rs.getString(3));
				m.setDividend_rate(rs.getDouble(4));
				res.add(m);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public int allCount() {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from match";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return cnt;
	}
	
	public int winCount(int hno) {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from match where hno=?";

		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(conn, pstmt, rs);
		}
		return cnt;
	}
}
