package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.BettingDao;
import dao.HorseDao;
import dao.MemberDao;
import dto.Betting;
import dto.Horse;
import dto.Member;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;

public class PurchaseGUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JLabel lblHno_;
	private JLabel lblName_;
	private JLabel lblAge_;
	private JLabel lblCm_;
	private JLabel lblKg_;
	private JLabel lblOdd_;
	private ArrayList<Horse> horseList;
	private String[] horseInfo = { "��ȣ", "�̸�", "����", "����(cm)", "����(kg)", "�·�" ,"����"};
	private int row = 0;
	private JTable table;
	private Horse h;
	private DefaultTableModel model;
	private JTextField tfNo;
	private JTextField tfMoney;
	private JLabel lblD_rate_;
	private JButton btnClose;
	private JButton btnCancel;
	private JButton btnIns;
	private static String id;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new PurchaseGUI(id);
					// frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws Exception
	 */

	public PurchaseGUI(String id) throws Exception {
		this.id = id;
		setTitle("���Ǳ���");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		horseDB();

		JPanel panelNorth = new JPanel();
		panelNorth.setBackground(Color.WHITE);
		contentPane.add(panelNorth, BorderLayout.NORTH);
		JLabel lblNewLabel = new JLabel("[ \uB9D0 \uBAA9\uB85D ]");
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 29));
		panelNorth.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));

		JPanel panelTop = new JPanel();
		panelTop.setBackground(Color.WHITE);
		panel_1.add(panelTop, BorderLayout.NORTH);
		panelTop.setLayout(new BorderLayout(0, 0));
		panelTop.setPreferredSize(new Dimension(800, 250));

		h = horseList.get(row);

		JScrollPane scrollPane = new JScrollPane(table);
		panelTop.add(scrollPane);

		JPanel panelBottom = new JPanel();
		panelBottom.setBackground(Color.WHITE);
		panel_1.add(panelBottom, BorderLayout.CENTER);
		panelBottom.setPreferredSize(new Dimension(800, 250));
		panelBottom.setLayout(new BorderLayout(0, 0));

		JPanel panelInfo = new JPanel();
		panelInfo.setBackground(Color.WHITE);
		panelBottom.add(panelInfo, BorderLayout.WEST);
		panelInfo.setLayout(new GridLayout(7, 2, 0, 0));
		panelInfo.setPreferredSize(new Dimension(300, 180));

		JLabel label_1 = new JLabel("\uBC88\uD638 : ");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(label_1);

		lblHno_ = new JLabel(h.getHno() + "��");
		lblHno_.setHorizontalAlignment(SwingConstants.CENTER);
		lblHno_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblHno_);

		JLabel lblName = new JLabel("\uC774\uB984 : ");
		lblName.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblName);

		lblName_ = new JLabel(h.getName());
		lblName_.setHorizontalAlignment(SwingConstants.CENTER);
		lblName_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblName_);

		JLabel lblAge = new JLabel("\uB098\uC774 : ");
		lblAge.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblAge.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblAge);

		lblAge_ = new JLabel(h.getAge() + "��");
		lblAge_.setHorizontalAlignment(SwingConstants.CENTER);
		lblAge_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblAge_);

		JLabel lblCm = new JLabel("\uC2E0\uC7A5(cm) : ");
		lblCm.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblCm.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblCm);

		lblCm_ = new JLabel(h.getHeight_cm() + "cm");
		lblCm_.setHorizontalAlignment(SwingConstants.CENTER);
		lblCm_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblCm_);

		JLabel lblKg = new JLabel("\uBB34\uAC8C(kg) : ");
		lblKg.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblKg.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblKg);

		lblKg_ = new JLabel((h.getWeight_kg() + "kg"));
		lblKg_.setHorizontalAlignment(SwingConstants.CENTER);
		lblKg_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblKg_);

		JLabel lblOdd = new JLabel("\uC2B9\uB960 : ");
		lblOdd.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblOdd.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblOdd);

		lblOdd_ = new JLabel((h.getOdds()*100 + "%"));
		lblOdd_.setHorizontalAlignment(SwingConstants.CENTER);
		lblOdd_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblOdd_);

		JLabel lblD_rate = new JLabel("\uBC30\uB2F9\uB960 : ");
		lblD_rate.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblD_rate.setHorizontalAlignment(SwingConstants.CENTER);
		panelInfo.add(lblD_rate);

		lblD_rate_ = new JLabel((h.getDividend_rate()*100 + "%"));
		lblD_rate_.setHorizontalAlignment(SwingConstants.CENTER);
		lblD_rate_.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		panelInfo.add(lblD_rate_);
		
		JPanel panelBtn = new JPanel();
		panelBtn.setBackground(Color.WHITE);
		panelBottom.add(panelBtn);
		panelBtn.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panelBtn.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(4, 2, 0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		panel.add(lblNewLabel_2);

		JLabel label = new JLabel("\uBC88\uD638 : ");
		panel.add(label);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));

		tfNo = new JTextField();
		tfNo.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel.add(tfNo);
		tfNo.setColumns(15);

		JLabel label_2 = new JLabel("\uAE08\uC561 : ");
		panel.add(label_2);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));

		tfMoney = new JTextField();
		tfMoney.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel.add(tfMoney);
		tfMoney.setColumns(15);

		JLabel label_3 = new JLabel("");
		label_3.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel.add(label_3);

		JLabel label_4 = new JLabel("");
		label_4.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel.add(label_4);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panelBtn.add(panel_2, BorderLayout.SOUTH);

		btnIns = new JButton("");
		btnIns.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnIns.png"));
		btnIns.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnIns.png"));
		btnIns.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnIns.png"));
		btnIns.setBorderPainted(false); btnIns.setFocusPainted(false); btnIns.setContentAreaFilled(false);
		btnIns.setPreferredSize(new Dimension(150, 50));
		panel_2.add(btnIns);
		btnIns.setFont(new Font("���� ����", Font.BOLD, 15));
		btnIns.setBackground(Color.WHITE);

		btnCancel = new JButton("");
		btnCancel.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCancel.png"));
		btnCancel.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCancel.png"));
		btnCancel.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCancel.png"));
		btnCancel.setBorderPainted(false); btnCancel.setFocusPainted(false); btnCancel.setContentAreaFilled(false);
		btnCancel.setPreferredSize(new Dimension(150, 50));
		panel_2.add(btnCancel);
		btnCancel.setFont(new Font("���� ����", Font.BOLD, 15));
		btnCancel.setBackground(Color.WHITE);

		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false); btnClose.setFocusPainted(false); btnClose.setContentAreaFilled(false);
		btnClose.setPreferredSize(new Dimension(150, 50));
		panel_2.add(btnClose);
		btnClose.setFont(new Font("���� ����", Font.BOLD, 15));
		btnClose.setBackground(Color.WHITE);
		btnClose.addActionListener(this);

		btnCancel.addActionListener(this);
		btnIns.addActionListener(this);

		setVisible(true);
	}

	private void horseDB() throws Exception {
		HorseDao dao = HorseDao.getInstance();
		horseList = dao.selectAll();
		DefaultTableModel tm = new DefaultTableModel(horseInfo, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				if (column >= 0)
					return false;
				else
					return true;
			}
		};
		Object[] obj = new Object[7];
		for (int i = 0; i < horseList.size(); i++) {
			Horse h = horseList.get(i);
			obj[0] = h.getHno();
			obj[1] = h.getName();
			obj[2] = h.getAge();
			obj[3] = h.getHeight_cm();
			obj[4] = h.getWeight_kg();
			obj[5] = h.getOdds();
			obj[6] = h.getDividend_rate();
			tm.addRow(obj);
		}
		table = new JTable(tm);
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				if (e.getClickCount() == 2) {
					row = table.getSelectedRow();
					lblSet(row);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
	}

	private void lblSet(int row) {
		Horse horse = horseList.get(row);
		lblHno_.setText(horse.getHno() + "��");
		lblName_.setText(horse.getName());
		lblAge_.setText(horse.getAge() + "��");
		lblCm_.setText(horse.getHeight_cm() + "cm");
		lblKg_.setText(horse.getWeight_kg() + "kg");
		lblOdd_.setText(horse.getOdds()*100 + "%");
		lblD_rate_.setText(horse.getDividend_rate()*100+"%");
		tfNo.setText(horse.getHno()+"");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// ��ư ���ý� �׿� �´� ��� ����.
		Object obj = e.getSource();
		if (obj == btnIns) {
			BettingDao bdao = BettingDao.getInstance();
			MemberDao mdao = MemberDao.getInstance();
			Member m = new Member();
			Betting b = new Betting();
			m = mdao.SelectOne(id);
			System.out.println(id);
			if(m.getDiv_money()>0) {
				JOptionPane.showMessageDialog(null, "����� �ް� ������ �����Ͻ� �� �ֽ��ϴ�.");
			}else {
				int money = Integer.parseInt(tfMoney.getText().toString());
				if (money > m.getMoney()) {
					JOptionPane.showMessageDialog(null, "�ݾ��� ���ڶ��ϴ�.");
				} else if (money <= m.getMoney()) {
					b.setHno(Integer.parseInt(tfNo.getText().toString()));
					b.setMno(m.getMno());
					b.setBet_money(money);
					int n = bdao.insert(b);
					Member rm = new Member();
					rm = m;
					rm.setMoney(m.getMoney()-money);
					int mn = mdao.update(rm);
					if (n ==1 && mn==1) {
						JOptionPane.showMessageDialog(null, "���ſ� �����Ͽ����ϴ�.");
						dispose();
						int cnt = bdao.count();
						if (cnt >= 5)
							LoginGUI.client.send(cnt);
					} else
						JOptionPane.showMessageDialog(null, "���ſ� �����Ͽ����ϴ�.");
				} else {
					try {
						JOptionPane.showMessageDialog(null, "������ �ʿ��մϴ�.");
					} catch (Exception e1) {

					}
				}
			}
		} else if (obj == btnCancel) {
			tfNo.setText("");
			tfMoney.setText("");
		} else {
			dispose();
		}

	}
}