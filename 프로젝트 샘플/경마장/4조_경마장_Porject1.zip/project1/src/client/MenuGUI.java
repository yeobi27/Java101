package client;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.MemberDao;
import dto.Member;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;

public class MenuGUI extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton btnAlloc;
	private JButton btnBuy;
	private JButton btnCharging;
	private JButton btnClose;
	private static String id;
	private JPanel panel;
	private JPanel panBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new MenuGUI(id);
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuGUI(String id) {
		this.id= id;
		ImageIcon main = new ImageIcon("images/main.jpg");
		setTitle("�޴�");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 800, 600);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel(){
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(main.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		contentPane.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panBtn.setPreferredSize(new Dimension(800, 100));
		panBtn.setForeground(Color.WHITE);
		panel.add(panBtn, BorderLayout.SOUTH);
		
		btnBuy = new JButton("");
		btnBuy.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnBuy.png"));
		btnBuy.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnBuy.png"));
		btnBuy.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnBuy.png"));
		btnBuy.setBorderPainted(false); btnBuy.setFocusPainted(false); btnBuy.setContentAreaFilled(false);
		panBtn.add(btnBuy);
		
		btnAlloc = new JButton("");
		btnAlloc.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnAlloc.png"));
		btnAlloc.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnAlloc.png"));
		btnAlloc.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnAlloc.png"));
		btnAlloc.setBorderPainted(false); btnAlloc.setFocusPainted(false); btnAlloc.setContentAreaFilled(false);
		panBtn.add(btnAlloc);
		
		btnCharging = new JButton("");
		btnCharging.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCharging.png"));
		btnCharging.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCharging.png"));
		btnCharging.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCharging.png"));
		btnCharging.setBorderPainted(false); btnCharging.setFocusPainted(false); btnCharging.setContentAreaFilled(false);
		panBtn.add(btnCharging);
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false); btnClose.setFocusPainted(false); btnClose.setContentAreaFilled(false);
		panBtn.add(btnClose);
		
		btnClose.addActionListener(this);
		btnCharging.addActionListener(this);
		btnAlloc.addActionListener(this);
		btnBuy.addActionListener(this);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if(obj==btnBuy) {
			try {
				new PurchaseGUI(id);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else if(obj==btnAlloc) {
			AllocMoney();
		}else if(obj==btnCharging) {
			new ChargingGUI(id);
		}else {
			dispose();
			new LoginGUI();
		}
	}

	private void AllocMoney() {
		// TODO Auto-generated method stub
		MemberDao mdao = MemberDao.getInstance();
		if(mdao.SelectOne(id).getDiv_money()!=0) {
			mdao.Alloc(id);
			JOptionPane.showMessageDialog(null, "����� �Ϸ�Ǿ����ϴ�.");
		}else {
			JOptionPane.showMessageDialog(null, "������ �����ϴ�.");
		}
	}
	
}
