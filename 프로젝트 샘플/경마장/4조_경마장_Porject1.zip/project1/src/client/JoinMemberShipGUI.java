package client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import dao.MemberDao;
import dto.Member;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Dimension;

public class JoinMemberShipGUI extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfName;
	private JTextField tfTel;
	private int idchk = 0;
	private JButton btnCheck;
	private JButton btnInsert;
	private JButton btnCancel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPasswordField tfPw;
	private JPasswordField tfPw1;
	private JButton btnClose;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JoinMemberShipGUI frame = new JoinMemberShipGUI();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JoinMemberShipGUI() {
		setTitle("ȸ������");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 600, 400);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 40));
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
		contentPane.add(panel_1, BorderLayout.CENTER);
		
		JLabel lblId = new JLabel("        ID        ");
		panel_1.add(lblId);
		lblId.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfId = new JTextField();
		tfId.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfId);
		tfId.setColumns(10);
		
		JLabel lblPw = new JLabel("    \uBE44\uBC00\uBC88\uD638   ");
		panel_1.add(lblPw);
		lblPw.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfPw = new JPasswordField();
		tfPw.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfPw.setEchoChar('*');
		tfPw.setColumns(10);
		panel_1.add(tfPw);
		
		JLabel lblPw1 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		panel_1.add(lblPw1);
		lblPw1.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblPw1.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfPw1 = new JPasswordField();
		tfPw1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		tfPw1.setEchoChar('*');
		tfPw1.setColumns(10);
		panel_1.add(tfPw1);
		
		JLabel lblName = new JLabel("       \uC774\uB984      ");
		panel_1.add(lblName);
		lblName.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfName = new JTextField();
		tfName.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfName);
		tfName.setColumns(10);
		
		JLabel lblTel = new JLabel("    \uD734\uB300\uC804\uD654   ");
		panel_1.add(lblTel);
		lblTel.setFont(new Font("Ÿ����_�ֹ��� B", Font.BOLD, 20));
		lblTel.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfTel = new JTextField();
		tfTel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfTel);
		tfTel.setColumns(10);
		
		panel_2 = new JPanel();
		panel_2.setPreferredSize(new Dimension(550, 70));
		panel_2.setBackground(Color.WHITE);
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		btnInsert = new JButton("");
		btnInsert.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnInsert.png"));
		btnInsert.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnInsert.png"));
		btnInsert.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnInsert.png"));
		btnInsert.setBorderPainted(false); btnInsert.setFocusPainted(false); btnInsert.setContentAreaFilled(false);
		panel_2.add(btnInsert);
		btnInsert.setFont(new Font("���ʷҹ���", Font.PLAIN, 20));
		
		btnCancel = new JButton("");
		btnCancel.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCancel.png"));
		btnCancel.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCancel.png"));
		btnCancel.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCancel.png"));
		btnCancel.setBorderPainted(false); btnCancel.setFocusPainted(false); btnCancel.setContentAreaFilled(false);
		panel_2.add(btnCancel);
		btnCancel.setFont(new Font("���ʷҹ���", Font.PLAIN, 20));
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false); btnClose.setFocusPainted(false); btnClose.setContentAreaFilled(false);
		btnClose.setFont(new Font("���ʷҹ���", Font.PLAIN, 20));
		panel_2.add(btnClose);
		
		panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		contentPane.add(panel_3, BorderLayout.EAST);
		
		btnCheck = new JButton("");
		btnCheck.setPreferredSize(new Dimension(150, 40));
		btnCheck.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCheck.png"));
		btnCheck.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCheck.png"));
		btnCheck.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCheck.png"));
		btnCheck.setBorderPainted(false); btnCheck.setFocusPainted(false); btnCheck.setContentAreaFilled(false);
		panel_3.add(btnCheck);

		btnCancel.addActionListener(this);
		btnInsert.addActionListener(this);
		btnCheck.addActionListener(this);
		btnClose.addActionListener(this);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == btnInsert) {
			String pw = new String(tfPw.getPassword());
			String pw1 = new String(tfPw1.getPassword());
			if(!pw.equals(pw1)) {
				tfPw1.setBackground(Color.RED);
				JOptionPane.showMessageDialog(null, "��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
			}else {
				tfPw1.setBackground(Color.GREEN);
				if(idchk==1) {
					MemberDao dao = MemberDao.getInstance();
					Member m = new Member();
					m.setId(tfId.getText());
					m.setPassword(pw);
					m.setName(tfName.getText());
					m.setTel(tfTel.getText());
					dao.insert(m);
					JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
					dispose();
				}else {
					JOptionPane.showMessageDialog(null, "ID �ߺ��� Ȯ���Ͽ� �ֽʽÿ�.");
				}
			}			
		}
		else if(obj==btnCancel) {
			tfId.setText("");
			tfPw.setText("");
			tfPw1.setText("");
			tfName.setText("");
			tfTel.setText("");
		}else if(obj==btnCheck) {
			if(tfId.getText()=="") JOptionPane.showMessageDialog(null, "ID�� �Է��� �ֽʽÿ�.");
			MemberDao dao = MemberDao.getInstance();
			String id = tfId.getText();
			int n = dao.idCheck(id);
			if(n==1) {
				JOptionPane.showMessageDialog(null, "����� �� ���� ID�Դϴ�.");
			}else {
				JOptionPane.showMessageDialog(null, "��밡���� ID�Դϴ�.");
				idchk = 1;
			}
		}else {
			dispose();
		}
	}
}
