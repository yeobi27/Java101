package client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.MemberDao;
import dto.Member;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import java.awt.Color;

public class ChargingGUI extends JFrame implements ActionListener {
	private JTextField tfMoney;
	private JPanel contentPane;
	private JButton btnCancel;
	private JButton btnCharging;
	private static String id;
	private Member m;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new ChargingGUI(id);
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChargingGUI(String id) {
		this.id= id;
		setTitle("�����ϱ�");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 400, 200);
		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panLbl = new JPanel();
		panLbl.setBackground(Color.WHITE);
		contentPane.add(panLbl, BorderLayout.NORTH);
		
		MemberDB();
		
		JLabel lblMoney = new JLabel("�ܾ� : " + m.getMoney());
		lblMoney.setBackground(Color.WHITE);
		lblMoney.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(lblMoney);
		
		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panBtn.setBounds(0, 78, 264, 33);
		getContentPane().add(panBtn, BorderLayout.SOUTH);
		
		btnCharging = new JButton("");
		btnCharging.setBackground(Color.WHITE);
		btnCharging.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCharging.png"));
		btnCharging.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCharging.png"));
		btnCharging.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCharging.png"));
		btnCharging.setBorderPainted(false); btnCharging.setFocusPainted(false); btnCharging.setContentAreaFilled(false);
		panBtn.add(btnCharging);
		btnCharging.addActionListener(this);
		
		btnCancel = new JButton("");
		btnCancel.setBackground(Color.WHITE);
		btnCancel.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnCancel.png"));
		btnCancel.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnCancel.png"));
		btnCancel.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnCancel.png"));
		btnCancel.setBorderPainted(false); btnCancel.setFocusPainted(false); btnCancel.setContentAreaFilled(false);
		panBtn.add(btnCancel);
		
		JPanel panMoney = new JPanel();
		panMoney.setBackground(Color.WHITE);
		contentPane.add(panMoney, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("\uAE08\uC561 :");
		lblNewLabel.setBackground(Color.WHITE);
		panMoney.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		lblNewLabel.setBounds(12, 28, 54, 27);
		
		tfMoney = new JTextField();
		tfMoney.setBackground(Color.WHITE);
		tfMoney.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panMoney.add(tfMoney);
		tfMoney.setBounds(71, 28, 160, 27);
		tfMoney.setColumns(10);
		btnCancel.addActionListener(this);
		
		setVisible(true);
	}
	
	private void MemberDB() {
		// TODO Auto-generated method stub
		MemberDao dao = MemberDao.getInstance();
		m = new Member();
		
		m = dao.SelectOne(id);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if(obj == btnCharging) {
			MemberDao dao = MemberDao.getInstance();
			Member m = dao.SelectOne(id);
			int money = Integer.parseInt(tfMoney.getText().toString())+m.getMoney();
			try {
				dao.Charging(id, money);
				JOptionPane.showMessageDialog(null, "�����Ǿ����ϴ�.");
				dispose();
			}catch(Exception e1) {
				JOptionPane.showMessageDialog(null, "������ �����Ͽ����ϴ�.");
			}
			
		}else {
			dispose();
		}
	}
	
}

