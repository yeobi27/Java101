package client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.MemberDao;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Frame;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.Color;

public class IdPwSearchGUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField tfTel;
	private JTextField tfName;
	private JTextField tfId;
	private JTextField tfName1;
	private JTextField tfTel1;
	private JButton btnPwS;
	private JButton btnIdS;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IdPwSearchGUI frame = new IdPwSearchGUI();
					// frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IdPwSearchGUI() {
		setTitle("���̵�/��й�ȣ ã��");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 600, 300);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 0, 0, 0));

		JPanel panelL = new JPanel();
		panelL.setBackground(Color.WHITE);
		contentPane.add(panelL);
		panelL.setLayout(new BorderLayout(0, 0));

		JPanel panLbl = new JPanel();
		panLbl.setBackground(Color.WHITE);
		panelL.add(panLbl, BorderLayout.NORTH);

		JLabel lblIdS = new JLabel("\uC544\uC774\uB514 \uCC3E\uAE30");
		lblIdS.setBackground(Color.WHITE);
		panLbl.add(lblIdS);
		lblIdS.setHorizontalAlignment(SwingConstants.CENTER);
		lblIdS.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 25));

		JPanel panCen = new JPanel();
		panCen.setBackground(Color.WHITE);
		panelL.add(panCen, BorderLayout.CENTER);
		panCen.setLayout(new GridLayout(0, 2, 0, 0));

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBackground(Color.WHITE);
		panCen.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBackground(Color.WHITE);
		panCen.add(lblNewLabel_3);

		JLabel label = new JLabel("\uC774          \uB984 :");
		label.setBackground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panCen.add(label);

		tfName = new JTextField();
		tfName.setBackground(Color.WHITE);
		tfName.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panCen.add(tfName);
		tfName.setColumns(10);

		JLabel lblTel = new JLabel("\uC804 \uD654 \uBC88 \uD638 :");
		lblTel.setBackground(Color.WHITE);
		lblTel.setHorizontalAlignment(SwingConstants.CENTER);
		lblTel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panCen.add(lblTel);

		tfTel = new JTextField();
		tfTel.setBackground(Color.WHITE);
		tfTel.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panCen.add(tfTel);
		tfTel.setColumns(10);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		panCen.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBackground(Color.WHITE);
		panCen.add(lblNewLabel_1);

		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panelL.add(panBtn, BorderLayout.SOUTH);

		btnIdS = new JButton("");
		btnIdS.setBackground(Color.WHITE);
		btnIdS.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnIdS.png"));
		btnIdS.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnIdS.png"));
		btnIdS.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnIdS.png"));
		btnIdS.setBorderPainted(false);
		btnIdS.setFocusPainted(false);
		btnIdS.setContentAreaFilled(false);
		panBtn.add(btnIdS);
		btnIdS.addActionListener(this);

		JPanel panelR = new JPanel();
		panelR.setBackground(Color.WHITE);
		contentPane.add(panelR);
		panelR.setLayout(new BorderLayout(0, 0));

		JPanel panLbl2 = new JPanel();
		panLbl2.setBackground(Color.WHITE);
		panelR.add(panLbl2, BorderLayout.NORTH);

		JLabel lblPwS = new JLabel("\uBE44\uBC00\uBC88\uD638 \uCC3E\uAE30");
		lblPwS.setBackground(Color.WHITE);
		panLbl2.add(lblPwS);
		lblPwS.setHorizontalAlignment(SwingConstants.CENTER);
		lblPwS.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 25));

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panelR.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(5, 2, 0, 0));

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBackground(Color.WHITE);
		panel_1.add(lblNewLabel_6);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBackground(Color.WHITE);
		panel_1.add(lblNewLabel_4);

		JLabel lblId = new JLabel("\uC544   \uC774   \uB514 :");
		lblId.setBackground(Color.WHITE);
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblId);

		tfId = new JTextField();
		tfId.setBackground(Color.WHITE);
		tfId.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfId);
		tfId.setColumns(10);

		JLabel lblName1 = new JLabel("\uC774         \uB984 :");
		lblName1.setBackground(Color.WHITE);
		lblName1.setHorizontalAlignment(SwingConstants.CENTER);
		lblName1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblName1);

		tfName1 = new JTextField();
		tfName1.setBackground(Color.WHITE);
		tfName1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfName1);
		tfName1.setColumns(10);

		JLabel lblTel1 = new JLabel("\uC804 \uD654 \uBC88 \uD638 :");
		lblTel1.setBackground(Color.WHITE);
		lblTel1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTel1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(lblTel1);

		tfTel1 = new JTextField();
		tfTel1.setBackground(Color.WHITE);
		tfTel1.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panel_1.add(tfTel1);
		tfTel1.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBackground(Color.WHITE);
		panel_1.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBackground(Color.WHITE);
		panel_1.add(lblNewLabel_7);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panelR.add(panel_2, BorderLayout.SOUTH);

		btnPwS = new JButton("");
		btnPwS.setBackground(Color.WHITE);
		btnPwS.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnPwS.png"));
		btnPwS.setPressedIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnPwS.png"));
		btnPwS.setRolloverIcon(
				new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnPwS.png"));
		btnPwS.setBorderPainted(false);
		btnPwS.setFocusPainted(false);
		btnPwS.setContentAreaFilled(false);
		panel_2.add(btnPwS);
		btnPwS.addActionListener(this);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();

		if (obj == btnIdS) {
			String name = tfTel.getText();
			String tel = tfName.getText();
			if (name.equals("") || tel.equals("")) {
				JOptionPane.showMessageDialog(null, "������ ��Ȯ�� �Է��Ͽ� �ֽʽÿ�.");
			} else {
				MemberDao dao = MemberDao.getInstance();
				String id = dao.IdS(name, tel);

				if (!id.equals("null"))
					JOptionPane.showMessageDialog(null, name + "���� ���̵�� " + id + " �Դϴ�");
				else
					JOptionPane.showMessageDialog(null, "ID�� �������� �ʽ��ϴ�.");
			}
		} else {
			String id = tfId.getText();
			String name = tfName1.getText();
			String tel = tfTel1.getText();

			if (id.equals("") || name.equals("") || tel.equals("")) {
				JOptionPane.showMessageDialog(null, "������ ��Ȯ�� �Է��Ͽ� �ֽʽÿ�.");
			} else {
				MemberDao dao = MemberDao.getInstance();
				String pw = dao.PwS(id, name, tel);

				if (!pw.equals("null"))
					JOptionPane.showMessageDialog(null, name + "���� ��й�ȣ�� " + pw + " �Դϴ�");
				else
					JOptionPane.showMessageDialog(null, "������ ��ġ���� �ʽ��ϴ�.");
			}
		}
	}
}
