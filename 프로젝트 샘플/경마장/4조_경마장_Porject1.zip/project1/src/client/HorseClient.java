package client;

import java.awt.Point;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ImageIcon;

public class HorseClient {
	Selector selector;
	SocketChannel socketChannel;
	LoginGUI LoginGUI;
	public static int idx;
	public static int x;
	HorseMatch hMatch;
	
	public HorseClient(LoginGUI LoginGUI){
		this.LoginGUI=LoginGUI;
	}
	void startClient(String address){
		try{
			selector=Selector.open();
		}catch(Exception e){
			if(socketChannel.isOpen()){
				stopClient();
			}
			return;
		}
		
		try{
			socketChannel=SocketChannel.open();
			socketChannel.configureBlocking(false);
			socketChannel.register(selector, SelectionKey.OP_CONNECT);
			socketChannel.connect(new InetSocketAddress(address,5100));
		}catch(Exception e){
			System.out.println("[������� �ȵ�0]");
			if(socketChannel.isOpen()){
				stopClient();
			}
			return;
		}
		Runnable runnable=new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true){
					try{
						int keyCount=selector.select();
						if(keyCount==0){
							continue;
						}
						Set<SelectionKey> selectedKeys=selector.selectedKeys();
						Iterator<SelectionKey> iterator=selectedKeys.iterator();
						while(iterator.hasNext()){
							SelectionKey selectionKey=iterator.next();
							if(selectionKey.isConnectable()){
								connect(selectionKey);
							}else if(selectionKey.isReadable()){
								receive(selectionKey);
							}else if(selectionKey.isWritable()){
								send(selectionKey);
							}
							iterator.remove();
						}
						
					}catch(Exception e){
						System.out.println("[������� �ȵ�1]");
						if(socketChannel.isOpen()){
							stopClient();
						}
						break;
					}
				}
			}
			
		};
		new Thread(runnable).start();
		
	} 
	
	void stopClient(){
		try{
			System.out.println("[�������]");
			if(socketChannel!=null && socketChannel.isOpen()){
				socketChannel.close();
			}
		}catch(IOException e){}
	}
	
	void connect(SelectionKey selectionKey){
		try{
			socketChannel.finishConnect();
			System.out.println("[����Ϸ�: "  + socketChannel.getRemoteAddress() + "]");
			selectionKey.interestOps(SelectionKey.OP_READ);
			selector.wakeup();
		}catch(Exception e){
			System.out.println("[������� �ȵ�2]");
			if(socketChannel.isOpen()){
				stopClient();
			}
		}
	}
	
	void receive(SelectionKey selectionKey){
		try {
			ByteBuffer byteBuffer = ByteBuffer.allocate(100);
			int byteCount = socketChannel.read(byteBuffer); 
			if(byteCount == -1) { 
				throw new IOException();
			}
			
			byteBuffer.flip();
			Charset charset = Charset.forName("MS949");
			String data = charset.decode(byteBuffer).toString();
			if(data.equals("TRUE")) {
				hMatch = new HorseMatch();
			}else if(data.contains(",")){
				String[] datastr = data.split(",");
				idx = Integer.parseInt(datastr[0]);
				x = Integer.parseInt(datastr[1]);
				if(x>=16) x /= 10;
				
				Point p = hMatch.lblHorse[idx].getLocation();
				hMatch.lblHorse[idx].setBounds(p.x+x,p.y,80,50);
				if(hMatch.lblHorse[idx].getX()>680) {
					hMatch.rank[idx] = hMatch.rankcnt++;
				}
				hMatch.cnt++;
				if (hMatch.cnt < 6) {
					ImageIcon icon = new ImageIcon("images/horse" + (hMatch.cnt + 1) + ".png");
					hMatch.lblHorse[idx].setIcon(icon);
				} else {
					hMatch.cnt = 0;
					ImageIcon icon = new ImageIcon("images/horse1.png");
					hMatch.lblHorse[idx].setIcon(icon);
				}
				if(hMatch.rankcnt==hMatch.lblHorse.length) {
					for(int i=0;i<hMatch.rankcnt;i++) {
						if(hMatch.rank[i]==1) {
							hMatch.chk = true;
						}
					}
				}
			}
			
			System.out.println("[�ޱ� �Ϸ�] "  + data);
		} catch(Exception e) {
			System.out.println("[���� ��� ����]");
			stopClient();
		}
	}
	

	void send(SelectionKey selectionKey){
		try {		
			ByteBuffer byteBuffer = (ByteBuffer) selectionKey.attachment();
			socketChannel.write(byteBuffer);
			System.out.println("[������ �Ϸ�]");
			selectionKey.interestOps(SelectionKey.OP_READ);
		} catch(Exception e) {
			System.out.println("[������� �ȵ�3]");
			stopClient();
		}
	}
	
	void send(int data) {
		String datastr = data+"";
		Charset charset = Charset.forName("MS949");
		ByteBuffer byteBuffer = charset.encode(datastr);
		SelectionKey key = socketChannel.keyFor(selector);
		key.attach(byteBuffer);
		key.interestOps(SelectionKey.OP_WRITE);
		selector.wakeup();
	}

}
