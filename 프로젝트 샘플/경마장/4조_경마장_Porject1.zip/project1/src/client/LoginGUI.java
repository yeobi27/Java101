package client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import client.JoinMemberShipGUI;
import dao.MemberDao;

import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.GridLayout;

public class LoginGUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfPw;
	static HorseClient client;
	private static String localhost = "127.0.0.1";
	private JButton btnLogin;
	private JButton btnMemberShip;
	private JButton btnIdPw;
	private JPanel panLbl;
	private JPanel panBtn_2;
	private JPanel panBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		ImageIcon main = new ImageIcon("images/main.jpg");
		setTitle("�α���");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(1000, 0, 800, 600);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(main.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));

		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(800, 130));
		panel_1.setBackground(Color.WHITE);
		panel.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new BorderLayout(0, 0));

		panLbl = new JPanel();
		panLbl.setBackground(Color.WHITE);
		panLbl.setPreferredSize(new Dimension(450, 200));
		panel_1.add(panLbl, BorderLayout.WEST);

		JLabel lblId = new JLabel("");
		lblId.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\lblId.png"));
		panLbl.add(lblId);
		lblId.setFont(new Font("����", Font.PLAIN, 15));
		lblId.setHorizontalAlignment(SwingConstants.CENTER);

		tfId = new JTextField();
		tfId.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(tfId);
		tfId.setColumns(10);

		JLabel lblPw = new JLabel("");
		lblPw.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\lblPw.png"));
		panLbl.add(lblPw);
		lblPw.setFont(new Font("����", Font.PLAIN, 15));
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);

		tfPw = new JPasswordField();
		tfPw.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 20));
		panLbl.add(tfPw);
		tfPw.setColumns(10);

		panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panel_1.add(panBtn, BorderLayout.CENTER);

		btnLogin = new JButton("");
		btnLogin.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnLogin.png"));
		btnLogin.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnLogin.png"));
		btnLogin.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnLogin.png"));
		btnLogin.setBorderPainted(false); btnLogin.setFocusPainted(false); btnLogin.setContentAreaFilled(false);
		panBtn.add(btnLogin);
		btnLogin.setFont(new Font("����", Font.PLAIN, 25));
		btnLogin.addActionListener(this);

		panBtn_2 = new JPanel();
		panBtn_2.setBackground(Color.WHITE);
		panel_1.add(panBtn_2, BorderLayout.EAST);
		panBtn_2.setLayout(new GridLayout(2, 0, 0, 0));

		btnMemberShip = new JButton("");
		btnMemberShip.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnJoin.png"));
		btnMemberShip.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnJoin.png"));
		btnMemberShip.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnJoin.png"));
		btnMemberShip.setBorderPainted(false); btnMemberShip.setFocusPainted(false); btnMemberShip.setContentAreaFilled(false);
		panBtn_2.add(btnMemberShip);
		btnMemberShip.setFont(new Font("����", Font.BOLD, 20));

		btnIdPw = new JButton("");
		btnIdPw.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnIdpwSearch.png"));
		btnIdPw.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnIdpwSearch.png"));
		btnIdPw.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnIdpwSearch.png"));
		btnIdPw.setBorderPainted(false
				); btnIdPw.setFocusPainted(false); btnIdPw.setContentAreaFilled(false);
		panBtn_2.add(btnIdPw);
		btnIdPw.setFont(new Font("����", Font.BOLD, 20));
		
		btnIdPw.addActionListener(this);
		btnMemberShip.addActionListener(this);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		client = new HorseClient(this);
		client.startClient(localhost);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if (obj == btnLogin) {
			String id = tfId.getText();
			String pw = tfPw.getText();
			
			
			MemberDao dao = MemberDao.getInstance();
			int n = dao.userConfirm(id, pw);
			if (n == 1) {
				JOptionPane.showMessageDialog(null, "�α��εǾ����ϴ�.");
				dispose();
				try {
					new MenuGUI(id);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} else if (n == 0) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� Ʋ�Ƚ��ϴ�.");
			} else if (n == -1) {
				JOptionPane.showMessageDialog(null, "��ġ�ϴ� ���̵� �����ϴ�.");
			}
		} else if (obj == btnMemberShip) {
			new JoinMemberShipGUI();
		} else  {
			new IdPwSearchGUI();
		}
	}
}
