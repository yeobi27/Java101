package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import dao.HorseDao;
import dto.Horse;

import java.awt.*;
import java.util.ArrayList;

public class HorseMatch extends JFrame implements ActionListener{

	private JPanel contentPane;
	private ArrayList<Horse> horseList;
	private JButton btnClose;
	public JLabel[] lblHorse;
	public int cnt = 0;
	public static int rank[];
	public int rankcnt = 1;
	public static boolean chk = false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HorseMatch hm = new HorseMatch();
					if(chk==true) {
						for(int i=0;i<rank.length;i++) {
							if(rank[i]==1) JOptionPane.showMessageDialog(null, "1��� " + rank[i] + "�� ���Դϴ� !!");
						}
						hm.dispose();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public HorseMatch() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(1000, 0, 800, 600);
		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		horseDB();
		rank = new int[horseList.size()];

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panLbl = new JPanel();
		panLbl.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		panLbl.setBackground(Color.WHITE);
		panel.add(panLbl, BorderLayout.CENTER);
		
		JLabel lbl = new JLabel("\uACBD\uB9C8 \uB300\uD68C");
		lbl.setBackground(Color.WHITE);
		lbl.setFont(new Font("Ÿ����_�ֹ��� B", Font.PLAIN, 27));
		panLbl.add(lbl);
		
		JPanel panBtn = new JPanel();
		panBtn.setBackground(Color.WHITE);
		panel.add(panBtn, BorderLayout.EAST);
		panBtn.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));
		
		btnClose = new JButton("");
		btnClose.setIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\btnClose.png"));
		btnClose.setPressedIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\setpressedbtnClose.png"));
		btnClose.setRolloverIcon(new ImageIcon("C:\\Users\\ChoiEunji\\javaProjects\\project1\\images\\rolloverbtnClose.png"));
		btnClose.setBorderPainted(false); btnClose.setFocusPainted(false); btnClose.setContentAreaFilled(false);
		panBtn.add(btnClose);
		btnClose.addActionListener(this);
		
		ImageIcon match_back = new ImageIcon("images/match_back.png");
		JPanel panHorse = new JPanel(){
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(match_back.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		contentPane.add(panHorse, BorderLayout.CENTER);
		panHorse.setLayout(null);
		
		lblHorse = new JLabel[rank.length];
		ImageIcon icon = new ImageIcon("images/horse1.png");
		int y =0;
		for(int i=0;i<horseList.size();i++) {
			lblHorse[i] = new JLabel(icon);
			lblHorse[i].setBounds(0, y, 80, 50);
			panHorse.add(lblHorse[i]);
			y+=85;
		}
		setVisible(true);
		
	}
	
	private void horseDB() throws Exception {
		// TODO Auto-generated method stub
		HorseDao dao = HorseDao.getInstance();
		horseList = dao.selectAll();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if(obj == btnClose) {
			if(JOptionPane.showConfirmDialog(null, "���� �����ðڽ��ϱ�? �����ø� �ٽ� ��⸦ �� �� �����ϴ�.","WARNING",JOptionPane.YES_NO_CANCEL_OPTION)==JOptionPane.YES_OPTION) {
				dispose();
			}
		}
	}
}



