package dto;

public class Horse_Condition {
	private int hno;
	private double sunny;
	private double cloud;
	private double rain;
	
	public Horse_Condition() {}

	public Horse_Condition(int hno, double sunny, double cloud, double rain) {
		super();
		this.hno = hno;
		this.sunny = sunny;
		this.cloud = cloud;
		this.rain = rain;
	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public double getSunny() {
		return sunny;
	}

	public void setSunny(double sunny) {
		this.sunny = sunny;
	}

	public double getCloud() {
		return cloud;
	}

	public void setCloud(double cloud) {
		this.cloud = cloud;
	}

	public double getRain() {
		return rain;
	}

	public void setRain(double rain) {
		this.rain = rain;
	}
}
