package dto;

public class Betting2 {
	private int bno;
	private int hno;
	private String hname;
	private int mno;
	private String mid;
	private int bet_money;
	
	public Betting2() {}
	
	public Betting2(int bno, int hno, String hname, int mno, String mid, int bet_money) {
		super();
		this.bno = bno;
		this.hno = hno;
		this.hname = hname;
		this.mno = mno;
		this.mid = mid;
		this.bet_money = bet_money;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public int getBet_money() {
		return bet_money;
	}
	public void setBet_money(int bet_money) {
		this.bet_money = bet_money;
	}
	
}
