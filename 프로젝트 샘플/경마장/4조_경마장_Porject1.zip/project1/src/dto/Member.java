package dto;

public class Member {
	private int mno;
	private String id;
	private String password;
	private String name;
	private String tel;
	private int money;
	private int div_money;
	
	public Member() {}
	public Member(int mno, String id, String password, String name, String tel, int money, int div_money) {
		super();
		this.setMno(mno);
		this.id = id;
		this.password = password;
		this.name = name;
		this.tel = tel;
		this.money = money;
		this.setDiv_money(div_money);
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public int getDiv_money() {
		return div_money;
	}
	public void setDiv_money(int div_money) {
		this.div_money = div_money;
	}
}
