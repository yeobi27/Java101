package dto;

public class Betting {
	private int bno;
	private int hno;
	private int mno;
	private int bet_money;
	
	public Betting() {}
	
	public Betting(int bno, int hno, int mno, int bet_money) {
		super();
		this.bno = bno;
		this.hno = hno;
		this.mno = mno;
		this.bet_money = bet_money;
	}

	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public int getBet_money() {
		return bet_money;
	}
	public void setBet_money(int bet_money) {
		this.bet_money = bet_money;
	}
	
}
