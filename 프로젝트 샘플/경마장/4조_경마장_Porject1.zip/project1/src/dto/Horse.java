package dto;

public class Horse {
	private int hno;
	private String name;
	private int age;
	private double height_cm;
	private double weight_kg;
	private double odds;
	private String imagename;
	private double dividend_rate;
	
	public Horse() {}
	public Horse(int hno, String name, int age, double height_cm, double weight_kg, String imagename, double odds, double dividend_rate) {
		super();
		this.hno = hno;
		this.name = name;
		this.age = age;
		this.height_cm = height_cm;
		this.weight_kg = weight_kg;
		this.setImagename(imagename);
		this.odds = odds;
		this.setDividend_rate(dividend_rate);
	}

	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getHeight_cm() {
		return height_cm;
	}
	public void setHeight_cm(double height_cm) {
		this.height_cm = height_cm;
	}
	public double getWeight_kg() {
		return weight_kg;
	}
	public void setWeight_kg(double weight_kg) {
		this.weight_kg = weight_kg;
	}
	public double getOdds() {
		return odds;
	}
	public void setOdds(double odds) {
		this.odds = odds;
	}
	public double getDividend_rate() {
		return dividend_rate;
	}
	public void setDividend_rate(double dividend_rate) {
		this.dividend_rate = dividend_rate;
	}
	public String getImagename() {
		return imagename;
	}
	public void setImagename(String imagename) {
		this.imagename = imagename;
	}
	
}
