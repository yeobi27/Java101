package dto;

public class Match2 {
	private int match_no;
	private int hno;
	private String hname;
	private double dividend_rate;
	
	public Match2() {}

	public Match2(int match_no, int hno, String hname, double dividend_rate) {
		super();
		this.match_no = match_no;
		this.hno = hno;
		this.hname = hname;
		this.dividend_rate = dividend_rate;
	}

	public int getMatch_no() {
		return match_no;
	}

	public void setMatch_no(int match_no) {
		this.match_no = match_no;
	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public double getDividend_rate() {
		return dividend_rate;
	}

	public void setDividend_rate(double dividend_rate) {
		this.dividend_rate = dividend_rate;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}
}
